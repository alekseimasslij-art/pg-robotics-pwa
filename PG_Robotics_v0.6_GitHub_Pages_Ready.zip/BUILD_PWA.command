#!/bin/zsh
set -e
cd "$(dirname "$0")"
echo 'PG Robotics — Flutter PWA release (iOS Safari / Android Chrome)'
./PREPARE_WEB.command
flutter build web --release --base-href "${PWA_BASE_HREF:-/}"
python3 tools/postbuild_pwa.py
echo ''
echo 'ГОТОВО: папка build/web — итоговая PWA.'
echo 'Для публичной HTTPS-ссылки загрузите содержимое build/web в Netlify Drop: https://app.netlify.com/drop'
echo 'НЕЛЬЗЯ проверять через file://, нужен веб-сервер.'
open build/web || true
read '?Enter — закрыть...'
