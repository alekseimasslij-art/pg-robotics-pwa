#!/bin/zsh
cd "$(dirname "$0")"
set -e
./PREPARE_IOS.command
flutter analyze
flutter test
echo 'Статическая проверка и тесты Flutter завершены.'
read '?Нажми Enter для закрытия...'
