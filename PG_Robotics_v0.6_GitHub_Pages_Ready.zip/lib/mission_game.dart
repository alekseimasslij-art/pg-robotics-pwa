import 'dart:math' as math;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';

// Fictional arcade, not a representation of real UAV capabilities or tactics.
// All entities use normalised coordinates, so touch and game logic are shared by iOS and web.
class MissionScreen extends StatefulWidget {
  const MissionScreen({super.key, required this.ukrainian, required this.active});
  final bool ukrainian;
  final bool active;
  @override
  State<MissionScreen> createState() => _MissionScreenState();
}

class _Enemy {
  _Enemy({required this.x, required this.y, required this.kind,
    required this.speed, required this.phase, required this.hp});
  double x, y, speed, phase;
  final int kind; // 0 scout, 1 zigzag, 2 armored, 3 elite
  int hp;
  double age = 0;
  double get radius => kind == 3 ? .074 : kind == 2 ? .058 : .045;
}
class _Bullet {
  _Bullet(this.x, this.y, this.dx, this.dy, this.pierce);
  double x, y, dx, dy;
  int pierce;
}
class _Drop {
  _Drop(this.x, this.y, this.kind);
  double x, y;
  final int kind; // 0 upgrade, 1 repair, 2 wingman, 3 shield
}
class _Burst {
  _Burst(this.x, this.y, this.ttl, this.tint);
  double x, y, ttl;
  final Color tint;
}

class _MissionScreenState extends State<MissionScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  static const _scoreKey = 'pg_mission_best_v2';
  static const _tierKey = 'pg_mission_best_tier_v2';
  final _rnd = math.Random();
  final ValueNotifier<int> _paintFrame = ValueNotifier<int>(0);
  double _lastHudRefresh = 0;
  late AnimationController _engine;
  final List<_Enemy> _enemies = [];
  final List<_Bullet> _bullets = [];
  final List<_Drop> _drops = [];
  final List<_Burst> _bursts = [];
  bool _running = false, _started = false, _gameOver = false;
  int _score = 0, _best = 0, _lives = 3, _tier = 0, _bestTier = 0;
  bool _wingman = false;
  double _playerX = .5, _playerY = .79;
  double _elapsed = 0, _spawnTimer = 0, _fireTimer = 0, _dropTimer = 0, _invulnerable = 0;
  DateTime? _prev;

  static const _names = ['PG Scout', 'LuckyStrike', 'LuckyShot', 'LuckyStrike-2'];
  String get _name => _names[_tier];
  String get _featureUa => ['Базовий імпульс', 'Подвійне пробиття',
    'Швидка серія', 'Широкий огляд'][_tier];
  String get _featureEn => ['Pulse shot', 'Piercing shot',
    'Rapid volley', 'Wide field'][_tier];
  int get _wave => (_elapsed / 19).floor() + 1;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _engine = AnimationController(vsync: this, duration: const Duration(minutes: 30))
      ..addListener(_tick);
    _load();
  }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _best = p.getInt(_scoreKey) ?? 0;
      _bestTier = p.getInt(_tierKey) ?? 0;
    });
  }
  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt(_scoreKey, _best);
    await p.setInt(_tierKey, _bestTier);
  }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) _pause();
  }
  @override
  void didUpdateWidget(covariant MissionScreen old) {
    super.didUpdateWidget(old);
    if (old.active && !widget.active) _pause();
  }
  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _engine.dispose();
    _paintFrame.dispose();
    super.dispose();
  }

  void _start({bool fresh = false}) {
    if (fresh || !_started || _gameOver) {
      _enemies.clear(); _bullets.clear(); _drops.clear(); _bursts.clear();
      _score = 0; _lives = 3; _tier = 0;
      _wingman = false; _elapsed = 0; _spawnTimer = 0;
      _fireTimer = 0; _dropTimer = 0; _invulnerable = 0;
      _playerX = .5; _playerY = .79; _lastHudRefresh = 0;
    }
    _prev = DateTime.now();
    HapticFeedback.selectionClick();
    setState(() { _started = true; _gameOver = false; _running = true; });
    _engine.repeat();
  }
  void _pause() {
    if (!_running) return;
    _engine.stop();
    _save();
    if (mounted) setState(() => _running = false);
  }
  void _die() {
    _engine.stop(); _running = false; _gameOver = true;
    if (_score > _best) _best = _score;
    _save();
    HapticFeedback.heavyImpact();
    if (mounted) setState(() {});
  }
  void _move(Offset pos, Size size) {
    if (!_running || size.width == 0 || size.height == 0) return;
    final scale = _tier == 3 ? .82 : 1.0;
    _playerX = (.5 + (pos.dx / size.width - .5) / scale).clamp(.075, .925).toDouble();
    _playerY = (.5 + (pos.dy / size.height - .5) / scale).clamp(.095, .91).toDouble();
    _paintFrame.value++;
  }
  void _damage() {
    if (_invulnerable > 0) return;
    _lives--;
    _invulnerable = 1.5;
    _bursts.add(_Burst(_playerX, _playerY, .42, const Color(0xFFFF745B)));
    HapticFeedback.mediumImpact();
    if (_lives <= 0) _die();
  }
  void _fire() {
    final y = _playerY - .038;
    if (_tier == 0) {
      _bullets.add(_Bullet(_playerX, y, 0, -.95, 1));
    } else if (_tier == 1) {
      _bullets.add(_Bullet(_playerX, y, 0, -.90, 2));
    } else if (_tier == 2) {
      _bullets.addAll([
        _Bullet(_playerX - .019, y, -.035, -1.12, 1),
        _Bullet(_playerX + .019, y, .035, -1.12, 1),
      ]);
    } else {
      _bullets.addAll([
        _Bullet(_playerX, y, 0, -1.08, 1),
        _Bullet(_playerX, y, -.20, -.99, 1),
        _Bullet(_playerX, y, .20, -.99, 1),
      ]);
    }
    if (_wingman) _bullets.add(_Bullet((_playerX + .085).clamp(.04, .96).toDouble(),
        (_playerY + .028).clamp(.03, .96).toDouble(), 0, -.98, 1));
    if (_bullets.length > 105) _bullets.removeRange(0, _bullets.length - 105);
  }
  void _spawn() {
    final roll = _rnd.nextDouble();
    final kind = _wave >= 5 && _rnd.nextDouble() < .075 ? 3
      : _wave >= 3 && roll < .24 ? 2
      : _wave >= 2 && roll < .55 ? 1 : 0;
    _enemies.add(_Enemy(x: .1 + _rnd.nextDouble() * .8, y: -.08,
      kind: kind, phase: _rnd.nextDouble() * math.pi * 2,
      speed: (kind == 3 ? .075 : kind == 2 ? .095 : kind == 1 ? .19 : .155)
        + math.min(_wave * .006, .072),
      hp: kind == 3 ? 7 : kind == 2 ? 3 : 1));
  }
  void _upgrade() {
    if (_tier < 3) {
      _tier++;
      if (_tier > _bestTier) _bestTier = _tier;
      HapticFeedback.heavyImpact();
      _save();
    } else {
      _score += 60; // Repeated blueprints become a score bonus.
    }
    _bursts.add(_Burst(_playerX, _playerY, .7, Palette.primary));
  }
  void _collect(_Drop drop) {
    _drops.remove(drop);
    switch (drop.kind) {
      case 0: _upgrade(); break;
      case 1: _lives = math.min(5, _lives + 1).toInt(); break;
      case 2: _wingman = true; break;
      case 3: _invulnerable = math.max(_invulnerable, 5.5); break;
    }
    _score += 5;
    _bursts.add(_Burst(drop.x, drop.y, .6, const Color(0xFF60E0C1)));
    HapticFeedback.lightImpact();
  }
  void _tick() {
    if (!mounted || !_running || !widget.active) return;
    final now = DateTime.now();
    final dt = _prev == null ? .016
        : (now.difference(_prev!).inMicroseconds / 1e6).clamp(0.0, .042).toDouble();
    _prev = now;
    if (dt <= 0) return;
    _elapsed += dt; _spawnTimer += dt; _fireTimer += dt; _dropTimer += dt;
    _invulnerable = math.max(0.0, _invulnerable - dt);
    final fireRate = _tier == 2 ? .115 : _tier == 3 ? .23 : _tier == 1 ? .31 : .28;
    if (_fireTimer >= fireRate) { _fireTimer = 0; _fire(); }
    if (_spawnTimer >= math.max(.36, .98 - _wave * .075)) {
      _spawnTimer = 0;
      if (_enemies.length < 28) _spawn();
    }
    // Guaranteed upgrades periodically, with other collectible types mixed in.
    if (_dropTimer >= (_tier < 3 ? 14.5 : 18.0)) {
      _dropTimer = 0;
      final k = _tier < 3 ? 0 : (_rnd.nextInt(3) + 1);
      _drops.add(_Drop(.12 + _rnd.nextDouble() * .76, -.06, k));
    }
    for (final b in _bullets) { b.x += b.dx * dt; b.y += b.dy * dt; }
    _bullets.removeWhere((b) => b.y < -.1 || b.x < -.1 || b.x > 1.1 || b.pierce <= 0);
    for (final e in _enemies) {
      e.age += dt;
      e.y += e.speed * dt;
      if (e.kind == 1) e.x += math.sin(e.age * 6 + e.phase) * dt * .25;
      if (e.kind == 3) e.x += math.sin(e.age * 2 + e.phase) * dt * .14;
      e.x = e.x.clamp(.06, .94).toDouble();
    }
    for (final d in _drops) d.y += dt * .18;
    for (final s in _bursts) s.ttl -= dt;
    _bursts.removeWhere((s) => s.ttl < 0);

    for (final e in List<_Enemy>.of(_enemies)) {
      bool destroyed = false;
      for (final b in List<_Bullet>.of(_bullets)) {
        if ((b.x - e.x).abs() < e.radius && (b.y - e.y).abs() < e.radius * .84) {
          b.pierce--;
          e.hp--;
          if (e.hp <= 0) {
            _score += e.kind == 3 ? 90 : e.kind == 2 ? 30 : e.kind == 1 ? 15 : 10;
            _bursts.add(_Burst(e.x, e.y, .52, const Color(0xFFFFD557)));
            _enemies.remove(e);
            if (_rnd.nextDouble() < .085 && _drops.length < 4) {
              _drops.add(_Drop(e.x, e.y, _rnd.nextBool() ? 1 : 2));
            }
            destroyed = true;
          }
          break;
        }
      }
      if (destroyed) continue;
      if ((e.x - _playerX).abs() < e.radius + .035 &&
          (e.y - _playerY).abs() < e.radius + .038) {
        _enemies.remove(e); _damage();
      } else if (e.y > 1.09) {
        _enemies.remove(e); _damage();
      }
    }
    for (final d in List<_Drop>.of(_drops)) {
      if ((d.x - _playerX).abs() < .07 && (d.y - _playerY).abs() < .07) {
        _collect(d);
      } else if (d.y > 1.06) {
        _drops.remove(d);
      }
    }
    if (_score > _best) _best = _score;
    _paintFrame.value++;
    // Keep the game painter at vsync while HUD rebuilds only about 7 times/sec.
    if (_elapsed - _lastHudRefresh > .14 && mounted) {
      _lastHudRefresh = _elapsed;
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final ua = widget.ukrainian;
    return LayoutBuilder(builder: (_, outer) {
      final fieldHeight = math.max(235.0, math.min(570.0, outer.maxHeight - 185));
      return SingleChildScrollView(
        key: const PageStorageKey('missionScrollV2'),
        padding: const EdgeInsets.fromLTRB(16, 13, 16, 20),
        physics: _running ? const NeverScrollableScrollPhysics()
            : const BouncingScrollPhysics(),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.radar_rounded, size: 17, color: Palette.primary),
            const SizedBox(width: 8),
            Expanded(child: Text(ua ? 'МІСІЯ / АРКАДА' : 'MISSION / ARCADE',
              style: const TextStyle(color: Palette.primary, fontSize: 12,
                fontWeight: FontWeight.w900, letterSpacing: 1.5))),
            IconButton(onPressed: _started && !_gameOver
                ? (_running ? _pause : () => _start()) : null,
              tooltip: ua ? 'Пауза / продовжити' : 'Pause / resume',
              icon: Icon(_running ? CupertinoIcons.pause_fill : CupertinoIcons.play_fill,
                  color: _started ? Palette.primary : Palette.tertiary)),
          ]),
          Row(children: [
            _Stat(ua ? 'РАХУНОК' : 'SCORE', '$_score'),
            const SizedBox(width: 7), _Stat(ua ? 'РЕКОРД' : 'BEST', '$_best'),
            const SizedBox(width: 7), _Stat(ua ? 'ЖИТТЯ' : 'LIVES', '$_lives / 5'),
          ]),
          const SizedBox(height: 11),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
            decoration: BoxDecoration(color: Palette.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Palette.border)),
            child: Row(children: [
              Container(width: 29, height: 29, alignment: Alignment.center,
                decoration: BoxDecoration(color: Palette.primary,
                  borderRadius: BorderRadius.circular(8)),
                child: Text('${_tier + 1}', style: const TextStyle(
                  color: Palette.background, fontWeight: FontWeight.w900))),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900)),
                Text(ua ? _featureUa : _featureEn,
                    style: const TextStyle(color: Palette.secondary, fontSize: 10.5)),
                Text(ua ? 'Найкраща модель: ${_names[_bestTier]}'
                  : 'Best unlocked: ${_names[_bestTier]}',
                  style: const TextStyle(color: Palette.tertiary, fontSize: 9.5)),
              ])),
              Text(ua ? 'ХВИЛЯ $_wave' : 'WAVE $_wave',
                  style: const TextStyle(color: Palette.primary, fontSize: 10,
                      fontWeight: FontWeight.w800, letterSpacing: .5)),
            ]),
          ),
          const SizedBox(height: 9),
          ClipRRect(borderRadius: BorderRadius.circular(18), child: SizedBox(
            height: fieldHeight, width: double.infinity,
            child: LayoutBuilder(builder: (_, field) {
              final size = Size(field.maxWidth, field.maxHeight);
              return GestureDetector(
                behavior: HitTestBehavior.opaque,
                onPanDown: (d) => _move(d.localPosition, size),
                onPanUpdate: (d) => _move(d.localPosition, size),
                onTapDown: (d) => _move(d.localPosition, size),
                child: Stack(fit: StackFit.expand, children: [
                  RepaintBoundary(child: AnimatedBuilder(
                    animation: _paintFrame,
                    builder: (_, __) => CustomPaint(painter: _MissionPainter(
                      enemies: _enemies, bullets: _bullets, drops: _drops,
                      bursts: _bursts, player: Offset(_playerX, _playerY),
                      elapsed: _elapsed, tier: _tier, wingman: _wingman,
                      shield: _invulnerable > 0,
                    )),
                  )),
                  if (!_running) Container(color: const Color(0xB500080C),
                    alignment: Alignment.center, padding: const EdgeInsets.all(22),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(_gameOver ? CupertinoIcons.refresh : Icons.flight_takeoff_rounded,
                          color: Palette.primary, size: 44),
                      const SizedBox(height: 16),
                      Text(_gameOver ? (ua ? 'МІСІЮ ЗАВЕРШЕНО' : 'MISSION OVER')
                        : _started ? (ua ? 'ПАУЗА' : 'PAUSED')
                        : (ua ? 'ГОТОВИЙ ДО ЗЛЬОТУ?' : 'READY TO FLY?'),
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 10),
                      Text(_gameOver ? '${ua ? 'Очки' : 'Score'}: $_score · ${ua ? 'Рекорд' : 'Best'}: $_best'
                        : (ua ? 'Рухай дрон пальцем у всіх напрямках.\nЗбирай підсилення та бережи життя.'
                          : 'Drag the drone in every direction.\nCollect upgrades and protect your lives.'),
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 12.5, color: Palette.secondary, height: 1.55)),
                      const SizedBox(height: 22),
                      YellowAction(title: _gameOver ? (ua ? 'Спробувати ще' : 'Try again')
                        : _started ? (ua ? 'Продовжити' : 'Continue')
                        : (ua ? 'Почати місію' : 'Start mission'),
                        onTap: () => _start(fresh: _gameOver)),
                    ])),
                  Positioned(left: 12, top: 10, child: Text('PG  /  ARCADE SIM',
                    style: TextStyle(color: Palette.primary.withValues(alpha: .65),
                      fontSize: 9, fontWeight: FontWeight.w900, letterSpacing: 1.3))),
                  if (_running) Positioned(right: 10, top: 10,
                      child: Icon(Icons.open_with_rounded, color: Palette.primary.withValues(alpha: .6), size: 17)),
                ]),
              );
            }),
          )),
          const SizedBox(height: 11),
          Text(ua ? 'Жовтий + — нова модель · ♥ — життя · 2 — супутник · ◈ — щит.'
            : 'Yellow + unlocks a drone · ♥ heals · 2 adds an ally · ◈ activates a shield.',
            style: const TextStyle(color: Palette.secondary, fontSize: 11, height: 1.4)),
          const SizedBox(height: 5),
          Text(ua ? 'Ігрові властивості вигадані й не відображають реальні ТТХ.'
            : 'Arcade abilities are fictional and do not represent real hardware specs.',
            style: const TextStyle(color: Palette.tertiary, fontSize: 10)),
        ]),
      );
    });
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.label, this.value);
  final String label, value;
  @override
  Widget build(BuildContext context) => Expanded(child: Container(
    height: 52, padding: const EdgeInsets.fromLTRB(10, 8, 4, 6),
    decoration: BoxDecoration(color: Palette.surface, border: Border.all(color: Palette.border),
      borderRadius: BorderRadius.circular(11)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(fontSize: 9, color: Palette.secondary,
          fontWeight: FontWeight.w700, letterSpacing: .5)),
        Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      ]),
  ));
}

class _MissionPainter extends CustomPainter {
  const _MissionPainter({required this.enemies, required this.bullets,
    required this.drops, required this.bursts, required this.player,
    required this.elapsed, required this.tier, required this.wingman,
    required this.shield});
  final List<_Enemy> enemies;
  final List<_Bullet> bullets;
  final List<_Drop> drops;
  final List<_Burst> bursts;
  final Offset player;
  final double elapsed;
  final int tier;
  final bool wingman, shield;
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;
    canvas.drawRect(Offset.zero & size, Paint()..shader = const LinearGradient(
      begin: Alignment.topCenter, end: Alignment.bottomCenter,
      colors: [Color(0xFF1D3037), Color(0xFF0D141B), Color(0xFF0A1014)],
    ).createShader(Offset.zero & size));
    final gridPaint = Paint()..color = const Color(0x1BFFDE19)..strokeWidth = .65;
    final spacing = tier == 3 ? 25.0 : 39.0; // Wide view simulates a larger field.
    final yOffset = (elapsed * 32) % spacing;
    for (double x = 0; x < w; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, h), gridPaint);
    }
    for (double y = -spacing; y < h; y += spacing) {
      canvas.drawLine(Offset(0, y + yOffset), Offset(w, y + yOffset), gridPaint);
    }
    canvas.drawLine(Offset(w * .5, 0), Offset(w * .5, h),
      Paint()..color = const Color(0x22FFDE19)..strokeWidth = 1);
    final factor = tier == 3 ? .82 : 1.0;
    Offset pt(double x, double y) => Offset(w * (.5 + (x - .5) * factor),
      h * (.5 + (y - .5) * factor));
    canvas.save(); canvas.clipRect(Offset.zero & size);
    for (final d in drops) {
      final p = pt(d.x, d.y);
      final yellow = d.kind == 0;
      final color = yellow ? Palette.primary : const Color(0xFF65E7C9);
      canvas.drawCircle(p, 17 * factor, Paint()..color = color.withValues(alpha: .18));
      final diamond = Path()..moveTo(p.dx, p.dy - 11 * factor)
        ..lineTo(p.dx + 11 * factor, p.dy)
        ..lineTo(p.dx, p.dy + 11 * factor)
        ..lineTo(p.dx - 11 * factor, p.dy)..close();
      canvas.drawPath(diamond, Paint()..color = color);
      final symbols = ['+', '♥', '2', '◈'];
      final symbol = TextPainter(text: TextSpan(text: symbols[d.kind],
        style: const TextStyle(color: Color(0xFF091113), fontSize: 12,
          fontWeight: FontWeight.w900)), textDirection: TextDirection.ltr)..layout();
      symbol.paint(canvas, p - Offset(symbol.width / 2, symbol.height / 2));
    }
    for (final b in bullets) {
      final p = pt(b.x, b.y);
      canvas.drawLine(p + Offset(0, 6 * factor), p - Offset(0, 10 * factor),
          Paint()..color = const Color(0xFFFFDE19)..strokeWidth = 3 * factor
            ..strokeCap = StrokeCap.round);
    }
    for (final e in enemies) {
      final p = pt(e.x, e.y);
      final s = factor * (e.kind == 3 ? 1.45 : e.kind == 2 ? 1.18 : 1);
      canvas.save(); canvas.translate(p.dx, p.dy); canvas.scale(s);
      final base = e.kind == 3 ? const Color(0xFFE76EAA)
        : e.kind == 2 ? const Color(0xFFFFA650)
        : e.kind == 1 ? const Color(0xFF67B6FF)
        : const Color(0xFFFF775D);
      if (e.kind == 2 || e.kind == 3) canvas.drawCircle(Offset.zero, 20,
        Paint()..color = base.withValues(alpha: .13));
      final armPaint = Paint()..color = const Color(0xFF8598A0)
        ..strokeWidth = 3.2..strokeCap = StrokeCap.round;
      canvas.drawLine(const Offset(-16, -12), const Offset(16, 12), armPaint);
      canvas.drawLine(const Offset(16, -12), const Offset(-16, 12), armPaint);
      for (final x in [-17.0, 17.0]) {
        for (final y in [-13.0, 13.0]) {
          canvas.drawCircle(Offset(x, y), 5, Paint()..color = base
            ..style = PaintingStyle.stroke..strokeWidth = 2);
        }
      }
      final shape = Path()..moveTo(0, 15)..lineTo(-9, 0)..lineTo(0, -15)
        ..lineTo(9, 0)..close();
      canvas.drawPath(shape, Paint()..color = base);
      if (e.kind >= 2) {
        canvas.drawCircle(Offset.zero, 3, Paint()..color = Colors.black);
      }
      canvas.restore();
    }
    for (final s in bursts) {
      final p = pt(s.x, s.y);
      final f = (s.ttl / .7).clamp(0.0, 1.0);
      canvas.drawCircle(p, (1 - f) * 32 + 8, Paint()
        ..color = s.tint.withValues(alpha: f)..strokeWidth = 2.2
        ..style = PaintingStyle.stroke);
    }
    final p = pt(player.dx, player.dy);
    _drawPlayer(canvas, p, factor);
    if (wingman) _drawPlayer(canvas, pt((player.dx + .085).clamp(.04, .97).toDouble(),
      (player.dy + .04).clamp(.03, .95).toDouble()), factor * .55);
    if (shield) canvas.drawCircle(p, 31 * factor, Paint()
      ..color = const Color(0xFF65E7C9).withValues(alpha: .7)
      ..strokeWidth = 2..style = PaintingStyle.stroke);
    canvas.restore();
  }
  void _drawPlayer(Canvas canvas, Offset p, double s) {
    canvas.save(); canvas.translate(p.dx, p.dy); canvas.scale(s);
    canvas.drawCircle(Offset.zero, 30, Paint()..color = const Color(0x18FFDE19));
    final arms = Paint()..color = const Color(0xFFE3D98A)
      ..strokeWidth = 4..strokeCap = StrokeCap.round;
    canvas.drawLine(const Offset(-20, -14), const Offset(20, 14), arms);
    canvas.drawLine(const Offset(20, -14), const Offset(-20, 14), arms);
    for (final x in [-22.0, 22.0]) {
      for (final y in [-16.0, 16.0]) {
        canvas.drawCircle(Offset(x, y), 6, Paint()..color = Palette.primary
          ..style = PaintingStyle.stroke..strokeWidth = 2);
      }
    }
    final body = Path()..moveTo(0, -24)..lineTo(11, 5)
      ..lineTo(0, 18)..lineTo(-11, 5)..close();
    canvas.drawPath(body, Paint()..color = Palette.primary);
    canvas.drawCircle(const Offset(0, 1), 3, Paint()..color = Colors.black);
    canvas.restore();
  }
  @override
  bool shouldRepaint(covariant _MissionPainter oldDelegate) => true;
}
