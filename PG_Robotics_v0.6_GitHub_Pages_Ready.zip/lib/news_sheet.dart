import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';

class NewsItem {
  NewsItem(Map<String, dynamic> j)
      : id = j['id'] as String,
        kind = j['kind'] as String,
        date = j['date'] as String,
        tagUa = j['tagUa'] as String,
        tagEn = j['tagEn'] as String,
        titleUa = j['titleUa'] as String,
        titleEn = j['titleEn'] as String,
        bodyUa = j['bodyUa'] as String,
        bodyEn = j['bodyEn'] as String;
  final String id, kind, date, tagUa, tagEn, titleUa, titleEn, bodyUa, bodyEn;
}

class DemoNewsStore {
  static const _seenKey = 'pg_demo_news_read_v1';
  static Future<List<NewsItem>> load() async {
    final raw = await rootBundle.loadString('assets/news/demo_news.json');
    final items = jsonDecode(raw) as List<dynamic>;
    return items.map((e) => NewsItem(e as Map<String, dynamic>)).toList();
  }
  static Future<Set<String>> seen() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList(_seenKey) ?? []).toSet();
  }
  static Future<void> saveSeen(Set<String> ids) async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList(_seenKey, ids.toList());
  }
}

class NewsSheet extends StatefulWidget {
  const NewsSheet({super.key, required this.ukrainian, required this.items,
    required this.seen, required this.onSeenChanged});
  final bool ukrainian;
  final List<NewsItem> items;
  final Set<String> seen;
  final ValueChanged<Set<String>> onSeenChanged;
  @override
  State<NewsSheet> createState() => _NewsSheetState();
}
class _NewsSheetState extends State<NewsSheet> {
  int _filter = 0;
  String? _expanded;
  late Set<String> _seen;
  @override
  void initState() {
    super.initState();
    _seen = {...widget.seen};
  }
  void _open(NewsItem item) {
    setState(() {
      _expanded = _expanded == item.id ? null : item.id;
      _seen.add(item.id);
    });
    DemoNewsStore.saveSeen(_seen);
    widget.onSeenChanged({..._seen});
  }
  @override
  Widget build(BuildContext context) {
    final ua = widget.ukrainian;
    final visible = widget.items.where((n) => _filter == 0 ||
      (_filter == 1 && n.kind == 'notification') ||
      (_filter == 2 && n.kind == 'news')).toList();
    return DraggableScrollableSheet(
      initialChildSize: .86, minChildSize: .34, maxChildSize: .97,
      expand: false,
      builder: (context, scrollController) => Container(
        clipBehavior: Clip.antiAlias,
        decoration: const BoxDecoration(color: Color(0xFF181B1E),
          borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
        child: ListView(controller: scrollController,
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(20, 11, 20, 34),
          children: [
            Center(child: Container(width: 44, height: 5,
              decoration: BoxDecoration(color: Palette.tertiary,
                borderRadius: BorderRadius.circular(10)))),
            const SizedBox(height: 24),
            Row(children: [
              Container(width: 43, height: 43, alignment: Alignment.center,
                decoration: BoxDecoration(color: const Color(0x20FFDE19),
                  borderRadius: BorderRadius.circular(13)),
                child: const Icon(CupertinoIcons.bell_fill, color: Palette.primary, size: 21)),
              const SizedBox(width: 13),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(ua ? 'Новини та сповіщення' : 'News & notifications',
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 21,
                    letterSpacing: -.65)),
                Text(ua ? 'Стрічка оновлень PG Robotics' : 'PG Robotics updates feed',
                  style: const TextStyle(color: Palette.secondary, fontSize: 11.5)),
              ])),
              IconButton(onPressed: () => Navigator.pop(context),
                tooltip: ua ? 'Закрити' : 'Close',
                icon: const Icon(CupertinoIcons.xmark, color: Palette.secondary, size: 19)),
            ]),
            const SizedBox(height: 15),
            Container(padding: const EdgeInsets.all(11),
              decoration: BoxDecoration(color: const Color(0x1EFFDE19),
                border: Border.all(color: const Color(0x50FFDE19)),
                borderRadius: BorderRadius.circular(11)),
              child: Row(children: [
                const Icon(CupertinoIcons.info_circle_fill,
                    color: Palette.primary, size: 17),
                const SizedBox(width: 9),
                Expanded(child: Text(ua
                  ? 'ДЕМО: ці публікації вигадані для тестування інтерфейсу. Push-повідомлення ще не підключено.'
                  : 'DEMO: sample articles for UI testing only. Remote push is not enabled yet.',
                  style: const TextStyle(fontSize: 11, height: 1.4, color: Palette.foreground))),
              ])),
            const SizedBox(height: 18),
            Wrap(spacing: 7, runSpacing: 7, children: List.generate(3, (i) {
              final names = ua ? ['Усі', 'Сповіщення', 'Новини'] : ['All', 'Alerts', 'News'];
              final active = _filter == i;
              return Padding(padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(label: Text(names[i]), selected: active,
                  onSelected: (_) => setState(() => _filter = i),
                  showCheckmark: false,
                  labelStyle: TextStyle(color: active ? Palette.background : Palette.secondary,
                    fontWeight: FontWeight.w800, fontSize: 11),
                  backgroundColor: Palette.surfaceRaised,
                  selectedColor: Palette.primary,
                  side: BorderSide(color: active ? Palette.primary : Palette.border),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))));
            })),
            const SizedBox(height: 16),
            for (final item in visible) ...[
              _NewsCard(item: item, ua: ua, opened: _expanded == item.id,
                read: _seen.contains(item.id), onTap: () => _open(item)),
              const SizedBox(height: 10),
            ],
          ]),
      ),
    );
  }
}

class _NewsCard extends StatelessWidget {
  const _NewsCard({required this.item, required this.ua, required this.opened,
    required this.read, required this.onTap});
  final NewsItem item;
  final bool ua, opened, read;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(
    color: Palette.surface,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15),
      side: const BorderSide(color: Palette.border)),
    child: InkWell(borderRadius: BorderRadius.circular(15), onTap: onTap,
      child: Padding(padding: const EdgeInsets.all(15),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(item.kind == 'news' ? CupertinoIcons.doc_text_fill
              : CupertinoIcons.bell_fill, color: Palette.primary, size: 14),
            const SizedBox(width: 6),
            Expanded(child: Text(ua ? item.tagUa : item.tagEn,
              style: const TextStyle(color: Palette.primary, fontSize: 9,
                letterSpacing: .75, fontWeight: FontWeight.w900))),
            Text(item.date, style: const TextStyle(color: Palette.tertiary, fontSize: 10)),
            if (!read) ...[const SizedBox(width: 8),
              Container(width: 7, height: 7, decoration: const BoxDecoration(
                color: Palette.primary, shape: BoxShape.circle))],
          ]),
          const SizedBox(height: 10),
          Text(ua ? item.titleUa : item.titleEn, style: const TextStyle(
            fontSize: 15, fontWeight: FontWeight.w800)),
          const SizedBox(height: 7),
          AnimatedSize(duration: const Duration(milliseconds: 270),
            curve: Curves.easeInOutCubic,
            alignment: Alignment.topCenter,
            child: Text(ua ? item.bodyUa : item.bodyEn,
              maxLines: opened ? null : 2,
              overflow: opened ? TextOverflow.visible : TextOverflow.ellipsis,
              style: const TextStyle(color: Palette.secondary, fontSize: 12.5,
                height: 1.58))),
          const SizedBox(height: 10),
          Row(children: [
            Text(opened ? (ua ? 'Згорнути' : 'Collapse') : (ua ? 'Читати' : 'Read'),
              style: const TextStyle(color: Palette.primary, fontSize: 11,
                fontWeight: FontWeight.w800)),
            const SizedBox(width: 4),
            Icon(opened ? CupertinoIcons.chevron_up : CupertinoIcons.chevron_down,
              color: Palette.primary, size: 12),
          ]),
        ])),
    ),
  );
}
