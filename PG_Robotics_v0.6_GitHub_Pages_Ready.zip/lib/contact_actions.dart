import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

/// Public business contacts shown on pg-robotics.com.
/// Direct links open outside the app; no checkout or account is created here.
abstract final class ContactActions {
  static const salesPhone = '+380673010141';
  static const supportPhone = '+380675309877';
  static const salesEmail = 'sales@pg-robotics.com';
  static const supportEmail = 'support@pg-robotics.com';

  static Future<void> whatsapp(BuildContext context, bool ukrainian) async {
    // First try the installed WhatsApp app. Use the official HTTPS link as
    // fallback for users who do not have the app (or when deep linking fails).
    try {
      final appUrl = Uri.parse('whatsapp://send?phone=380673010141');
      if (await launchUrl(appUrl, mode: LaunchMode.externalApplication)) return;
    } catch (_) {}
    final webUrl = Uri.https('wa.me', '/380673010141');
    await _open(context, webUrl, ukrainian, fallback: salesPhone);
  }

  static Future<void> phone(
      BuildContext context, String number, bool ukrainian) async {
    await _open(context, Uri(scheme: 'tel', path: number), ukrainian,
        fallback: number);
  }

  static Future<void> email(
      BuildContext context, String address, bool ukrainian) async {
    await _open(context, Uri(scheme: 'mailto', path: address), ukrainian,
        fallback: address);
  }

  static Future<void> _open(
    BuildContext context,
    Uri target,
    bool ukrainian, {
    required String fallback,
  }) async {
    try {
      if (await launchUrl(target, mode: LaunchMode.externalApplication)) return;
    } catch (_) {
      // No compatible app installed, permissions denied, or cannot resolve URI.
    }
    await Clipboard.setData(ClipboardData(text: fallback));
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(ukrainian
          ? 'Не вдалося відкрити застосунок. Контакт скопійовано.'
          : 'Could not open the app. Contact was copied.'),
    ));
  }
}
