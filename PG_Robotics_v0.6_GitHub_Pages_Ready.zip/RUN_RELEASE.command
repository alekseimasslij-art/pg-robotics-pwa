#!/bin/zsh
cd "$(dirname "$0")"
echo "PG Robotics v0.6 — установка на iPhone в RELEASE"
echo "Сборка через Flutter SDK на твоём Mac, без старых Xcode-файлов."

if ! ./PREPARE_IOS.command; then
  echo "ОШИБКА: подготовка iOS проекта не удалась. Лог выше."
  read '?Нажми Enter для закрытия...'
  exit 1
fi

echo "Подключи и разблокируй iPhone (USB рекомендуется)."
if ! flutter run --release; then
  echo "ОШИБКА: установка/сборка не завершилась. Пришли последние 30 строк лога."
  read '?Нажми Enter для закрытия...'
  exit 1
fi

echo "Готово. Приложение можно запускать с иконки на iPhone."
read '?Нажми Enter для закрытия...'
