#!/bin/zsh
set -e
cd "$(dirname "$0")"
./PREPARE_WEB.command
# Development HTTP server: accessible from other devices on the same LAN.
# iOS install/offline features require HTTPS on an actual host.
flutter run -d web-server --web-hostname 0.0.0.0 --web-port 8080
