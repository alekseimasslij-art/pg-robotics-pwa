import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:pg_robotics_app/main.dart';
import 'package:pg_robotics_app/mission_game.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));

  testWidgets('five independent tabs, no stacked/ghost page content',
      (tester) async {
    await tester.pumpWidget(const PgRoboticsApp());
    await tester.pumpAndSettle();
    final nav = find.byType(NativeTabBar);
    expect(nav, findsOneWidget);
    expect(tester.widget<NativeTabBar>(nav).selectedTab, 0);
    final contacts = find.descendant(
      of: nav, matching: find.text('Контакти'));
    await tester.tap(contacts);
    await tester.pumpAndSettle();
    expect(find.text('Прямий зв’язок'), findsOneWidget);
    expect(tester.widget<NativeTabBar>(nav).selectedTab, 4);

    final company = find.descendant(
      of: nav, matching: find.text('Компанія'));
    await tester.tap(company);
    await tester.pumpAndSettle();
    // The previous implementation used a Stack of AnimatedOpacity widgets;
    // hidden pages were still paintable and appeared over one another on iOS.
    expect(find.text('Прямий зв’язок'), findsNothing);
    expect(tester.widget<NativeTabBar>(nav).selectedTab, 3);
    expect(find.byType(IndexedStack), findsOneWidget);
  });

  testWidgets('catalog product opens native detail with contact action',
      (tester) async {
    await tester.pumpWidget(const PgRoboticsApp());
    await tester.pumpAndSettle();
    final productsTab = find.descendant(
      of: find.byType(NativeTabBar), matching: find.text('Продукція'));
    await tester.tap(productsTab);
    await tester.pumpAndSettle();
    final model = find.descendant(
      of: find.byType(CatalogScreen), matching: find.text('LuckyStrike'));
    await tester.tap(model);
    await tester.pumpAndSettle();
    expect(find.byType(ProductDetail), findsOneWidget);
    expect(find.text('LUCKYSTRIKE'), findsOneWidget);
    expect(find.text('Зв’язатися з менеджером'), findsOneWidget);
  });

  testWidgets('mission is a distinct playable offline screen', (tester) async {
    await tester.pumpWidget(const PgRoboticsApp());
    await tester.pumpAndSettle();
    final missionTab = find.descendant(
      of: find.byType(NativeTabBar), matching: find.text('Місія'));
    await tester.tap(missionTab);
    await tester.pumpAndSettle();
    expect(find.byType(MissionScreen), findsOneWidget);
    expect(find.text('Почати місію'), findsOneWidget);
    expect(find.text('РЕКОРД'), findsOneWidget);
  });

  testWidgets('home is a functional mobile dashboard', (tester) async {
    await tester.pumpWidget(const PgRoboticsApp());
    await tester.pumpAndSettle();
    expect(find.text('Наші розробки'), findsOneWidget);
    expect(find.text('Інженерія\nв дії.'), findsOneWidget);
    await tester.tap(find.text('Наші розробки'));
    await tester.pumpAndSettle();
    expect(tester.widget<NativeTabBar>(find.byType(NativeTabBar)).selectedTab, 1);
  });

  testWidgets('company innovation card actually opens catalog', (tester) async {
    await tester.pumpWidget(const PgRoboticsApp());
    await tester.pumpAndSettle();
    await tester.tap(find.descendant(of: find.byType(NativeTabBar),
      matching: find.text('Компанія')));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('Інновації'));
    await tester.tap(find.text('Інновації'));
    await tester.pumpAndSettle();
    expect(tester.widget<NativeTabBar>(find.byType(NativeTabBar)).selectedTab, 1);
  });

  testWidgets('bell opens news feed bottom sheet and closes', (tester) async {
    await tester.pumpWidget(const PgRoboticsApp());
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('Новини та сповіщення'));
    await tester.pumpAndSettle();
    expect(find.text('Новини та сповіщення'), findsWidgets);
    expect(find.textContaining('ДЕМО'), findsWidgets);
    await tester.tap(find.byTooltip('Закрити'));
    await tester.pumpAndSettle();
  });

  testWidgets('language toggle updates tab labels', (tester) async {
    await tester.pumpWidget(const PgRoboticsApp());
    await tester.tap(find.text('EN'));
    await tester.pumpAndSettle();
    final products = find.descendant(
      of: find.byType(NativeTabBar), matching: find.text('Products'));
    expect(products, findsOneWidget);
    expect(find.text('Mission'), findsOneWidget);
  });
}

// Additional cross-platform regressions live below in the original test suite
// so both `flutter test` and `flutter test --platform chrome` (if configured)
// exercise the same core UI. The actual release build must still be tested
// on real iPhone and mobile Safari/Chrome devices.
