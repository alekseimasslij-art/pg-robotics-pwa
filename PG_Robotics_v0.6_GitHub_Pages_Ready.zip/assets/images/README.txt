Place exact original PG Robotics website photographs here:
hero.jpg
luckystrike.jpg
luckystrike2.jpg
luckyshot.jpg
uavkit.jpg
about.jpg

No stock, generated, or third-party drone photos are packaged.
Until original photographs are placed here, native UI shows neutral branded placeholders.
Use tools/capture_official_assets.py followed by tools/assign_site_assets.py.
