#!/bin/zsh
set -e
cd "$(dirname "$0")"

if ! command -v flutter >/dev/null 2>&1; then
  echo "ОШИБКА: Flutter SDK не найден. Проверь PATH и установку Flutter."
  exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo "ОШИБКА: python3 не найден. Он требуется для изменения iOS Info.plist."
  exit 1
fi

# Old handmade iOS directories from v0.2/v0.3/v0.4 must NOT be copied here.
# This archive intentionally ships Flutter sources but no ios/ project.
if [[ ! -f ios/Runner.xcodeproj/project.pbxproj ]]; then
  echo "Первый запуск: создаём стандартный iOS Runner через локальный Flutter SDK..."
  flutter create --platforms=ios --org com.example --project-name pg_robotics_app --no-pub .
else
  echo "Используем ранее созданный Runner из этой папки."
fi

python3 tools/configure_ios.py
flutter pub get
