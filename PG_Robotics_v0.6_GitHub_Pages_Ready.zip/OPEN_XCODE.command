#!/bin/zsh
cd "$(dirname "$0")"
if ! ./PREPARE_IOS.command; then
  read '?Нажми Enter для закрытия...'
  exit 1
fi
if [[ -f ios/Runner.xcworkspace/contents.xcworkspacedata ]]; then
  open ios/Runner.xcworkspace
else
  open ios/Runner.xcodeproj
fi
