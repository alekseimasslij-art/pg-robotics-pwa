#!/bin/zsh
cd "$(dirname "$0")"
echo "PG Robotics — DEBUG на iPhone (для Hot Reload)."
if ! ./PREPARE_IOS.command; then
  read '?Нажми Enter для закрытия...'
  exit 1
fi
if ! flutter run; then
  echo "Debug завершён с ошибкой."
  read '?Нажми Enter для закрытия...'
  exit 1
fi
