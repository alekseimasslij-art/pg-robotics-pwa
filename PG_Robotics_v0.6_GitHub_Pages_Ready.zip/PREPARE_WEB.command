#!/bin/zsh
set -e
cd "$(dirname "$0")"
if ! command -v flutter >/dev/null 2>&1; then
  echo 'Flutter SDK не найден. Проверь PATH.'; exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo 'Не найден Python3.'; exit 1
fi
if [[ ! -f web/index.html ]]; then
  echo 'Генерируем web платформу текущим Flutter SDK...'
  flutter create --platforms=web --org com.example --project-name pg_robotics_app --no-pub .
fi
python3 tools/configure_web.py
flutter pub get
