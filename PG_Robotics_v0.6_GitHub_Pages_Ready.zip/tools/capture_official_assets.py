#!/usr/bin/env python3
"""Capture exact original images actually requested by the PG Robotics website.

Requirements:
  pip3 install playwright
  python3 -m playwright install chromium

This does not draw, synthesize, alter or resize photos. Files retain source bytes.
Only URLs present on the website during an interactive browser session are used.
"""
from __future__ import annotations
import hashlib
import html
import json
import mimetypes
from pathlib import Path
from urllib.parse import urlparse
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / 'tools' / 'site_import'
RAW = DEST / 'originals'
TARGETS = ['hero', 'luckystrike', 'luckystrike2', 'luckyshot', 'uavkit', 'about']
URLS = ['https://pg-robotics.com/', 'https://pg-robotics.com/about']

JAVASCRIPT = r'''() => {
  const found = [];
  const add = (url, hint, tag) => {
    if (!url || url.startsWith('data:') || url.startsWith('blob:')) return;
    try { found.push({url: new URL(url, location.href).href, hint: (hint || '').trim().slice(0,180), tag}); }
    catch(_) {}
  };
  for(const img of document.images) {
    add(img.currentSrc || img.src, img.alt || img.closest('a')?.innerText ||
       img.parentElement?.innerText, 'img');
    if(img.srcset) for(const u of img.srcset.split(',')) add(u.trim().split(/\s+/)[0], img.alt, 'srcset');
  }
  for(const e of document.querySelectorAll('*')) {
    const s = getComputedStyle(e);
    const bg = s.backgroundImage;
    if(bg && bg !== 'none') {
      for(const m of bg.matchAll(/url\(["']?(.*?)["']?\)/g))
        add(m[1], e.getAttribute('aria-label') || e.innerText.slice(0,100), 'background');
    }
  }
  for(const e of document.querySelectorAll('video[poster]')) add(e.poster, 'Video poster', 'poster');
  const og = document.querySelector('meta[property="og:image"]');
  if(og) add(og.content, 'Social image', 'og');
  return found;
}'''


def main():
    RAW.mkdir(parents=True, exist_ok=True)
    record = {}
    with sync_playwright() as pw:
        browser = pw.chromium.launch(headless=True)
        page = browser.new_page(viewport={'width': 1340, 'height': 900},
                                device_scale_factor=1)
        responses = []
        def capture_response(resp):
            if resp.request.resource_type in ('image', 'font'):
                responses.append((resp.url, resp.request.resource_type))
        page.on('response', capture_response)
        for address in URLS:
            try:
                page.goto(address, wait_until='domcontentloaded', timeout=45000)
                page.wait_for_timeout(2500)
                for _ in range(14):
                    page.mouse.wheel(0, 800)
                    page.wait_for_timeout(230)
                page.mouse.wheel(0, -10000)
                page.wait_for_timeout(400)
                for image in page.evaluate(JAVASCRIPT):
                    record.setdefault(image['url'], {'url': image['url'],
                        'hint': image['hint'], 'tag': image['tag'],
                        'page': address, 'kind': 'image'})
            except Exception as ex:
                print(f'Could not scan {address}: {ex}')
        for url, kind in responses:
            if kind == 'image':
                record.setdefault(url, {'url': url, 'hint': '',
                    'tag': 'resource', 'page': 'network', 'kind': kind})
        print('URLs identified:', len(record))
        items=[]
        for item in record.values():
            url = item['url']
            try:
                resp = page.request.get(url, timeout=25000)
                if not resp.ok:
                    continue
                data = resp.body()
                if not data or len(data) > 20_000_000:
                    continue
                ct = resp.headers.get('content-type', '').split(';')[0].lower()
                if ct not in ('image/jpeg','image/png','image/webp','image/gif','image/avif','image/svg+xml'):
                    continue
                ext = { 'image/jpeg':'.jpg', 'image/png':'.png',
                    'image/webp':'.webp','image/gif':'.gif',
                    'image/avif':'.avif','image/svg+xml':'.svg'}[ct]
                sha = hashlib.sha1(data).hexdigest()[:14]
                name = f'{sha}{ext}'
                (RAW / name).write_bytes(data)
                items.append({**item, 'file': f'originals/{name}',
                    'bytes': len(data), 'type': ct})
                print(f'✓ {name} {item["hint"][:38]}')
            except Exception as ex:
                print(f'Skip {url[:80]}: {ex}')
        font_items = []
        fonts_dir = DEST / 'fonts'
        fonts_dir.mkdir(exist_ok=True)
        for url, kind in dict.fromkeys(responses):
            if kind != 'font':
                continue
            try:
                resp = page.request.get(url, timeout=25000)
                if not resp.ok:
                    continue
                data = resp.body()
                if not data or len(data) > 3_000_000:
                    continue
                path_extension = Path(urlparse(url).path).suffix.lower()
                extension = path_extension if path_extension in ('.woff', '.woff2', '.ttf', '.otf') else '.woff2'
                filename = hashlib.sha1(data).hexdigest()[:14] + extension
                (fonts_dir / filename).write_bytes(data)
                font_items.append({'url': url, 'file': 'fonts/' + filename,
                                   'bytes': len(data)})
                print('Font asset:', filename)
            except Exception as ex:
                print('Font skipped:', ex)
        (DEST / 'fonts.json').write_text(json.dumps(font_items, indent=2,
            ensure_ascii=False), encoding='utf-8')
        browser.close()
    (DEST / 'manifest.json').write_text(json.dumps(items, indent=2, ensure_ascii=False), encoding='utf-8')
    blocks=[]
    for i,item in enumerate(items):
        url=html.escape(item['url'], quote=True)
        hint=html.escape(item['hint'])
        filename=html.escape(item['file'])
        blocks.append(f'<article><b>#{i}</b><img src="{filename}"><p>{hint}</p>'
                      f'<small>{item["tag"]} • {item["bytes"]:,} bytes</small>'
                      f'<p><a href="{url}" target="_blank">Original source</a></p></article>')
    contents='''<!doctype html><meta charset="utf-8"><title>PG Original Asset Picker</title>
      <style>body{font:15px Arial;background:#111;color:#eee;margin:24px}
      h1{color:#ffde18}main{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:14px}
      article{background:#262626;padding:12px;border-radius:12px;overflow:hidden}
      img{width:100%;height:180px;object-fit:contain;background:#333}
      a{color:#ffde18}p{overflow-wrap:anywhere}small{color:#aaa}</style>
      <h1>PG Robotics — original on-site media</h1><p>Source bytes are unmodified.
      Choose the image number for each target. If an image does not match a model,
      do not assign it to that model.</p><main>'''+''.join(blocks)+'</main>'
    (DEST / 'gallery.html').write_text(contents, encoding='utf-8')
    print(f'\nGallery: {DEST / "gallery.html"}')
    print('Assign examples:')
    print(' python3 tools/assign_site_assets.py hero=0 luckystrike=1 luckystrike2=2 about=3')
    print(f'Targets: {", ".join(TARGETS)}')

if __name__ == '__main__':
    main()
