#!/usr/bin/env python3
"""Copy selected exact original site image bytes to Flutter asset slots.

After running capture_official_assets.py and checking its gallery.html:
  python3 tools/assign_site_assets.py hero=3 luckystrike=1 luckystrike2=7

Numbers refer to image numbers in gallery.html, not to product IDs.
Only raster images are supported in the Flutter showcase.
"""
import json
import shutil
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DEST=ROOT/'tools'/'site_import'
OUT=ROOT/'assets'/'images'
SLOTS={'hero', 'luckystrike', 'luckystrike2', 'luckyshot', 'uavkit', 'about'}


def main():
    manifest=DEST/'manifest.json'
    if not manifest.exists():
        sys.exit('Capture website assets first: python3 tools/capture_official_assets.py')
    data=json.loads(manifest.read_text(encoding='utf-8'))
    if len(sys.argv)<2:
        sys.exit('Example: python3 tools/assign_site_assets.py hero=2 luckystrike2=9')
    for part in sys.argv[1:]:
        if '=' not in part: sys.exit(f'Expected slot=number, got {part!r}')
        slot, n=part.split('=',1)
        if slot not in SLOTS: sys.exit(f'Unknown slot: {slot}. Expected {sorted(SLOTS)}')
        try: item=data[int(n)]
        except (ValueError, IndexError): sys.exit(f'Invalid gallery number: {n}')
        if item['type'] not in ('image/jpeg','image/webp','image/png'):
            sys.exit(f'Unsupported raster format for Flutter photo: {item["type"]}')
        source=DEST/item['file']
        target=OUT/f'{slot}.jpg'
        shutil.copyfile(source,target) # Byte-exact copy; Flutter sniffs raster bytes.
        print(f'{slot}.jpg ← {source.name} ({item["bytes"]} bytes)')
    print('Done. Restart Flutter to include the new assets (flutter run).')

if __name__ == '__main__': main()
