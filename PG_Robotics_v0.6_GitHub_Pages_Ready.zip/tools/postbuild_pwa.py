#!/usr/bin/env python3
"""Generate versioned offline cache for a Flutter web release without replacing Flutter code."""
from pathlib import Path
import hashlib
import json
import sys
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'build'/'web'

def main():
    if not (OUT/'index.html').exists() or not (OUT/'main.dart.js').exists():
        raise RuntimeError('Flutter web release is absent; run flutter build web first')
    main_js=(OUT/'main.dart.js').read_bytes()
    version=hashlib.sha256(main_js).hexdigest()[:12]
    required=['index.html','flutter_bootstrap.js','main.dart.js','manifest.json','favicon.png','apple-touch-icon.png']
    # Essential entry files, a local offline fallback, and small Flutter asset manifests.
    for fn in ['assets/AssetManifest.bin','assets/FontManifest.json','assets/NOTICES.Z',
               'icons/Icon-192.png','icons/Icon-512.png','assets/news/demo_news.json']:
        if (OUT/fn).exists(): required.append(fn)
    required=[x for x in required if (OUT/x).exists()]
    # Relative URLs work even for installations served from a subdirectory.
    js = f'''// Generated for PG Robotics web build {version}; shared Flutter code for iOS and PWA.
const CACHE = 'pg-robotics-{version}';
const PREFIX = 'pg-robotics-';
const START = {json.dumps(required, ensure_ascii=False)};
self.addEventListener('install', event => {{
  event.waitUntil(caches.open(CACHE).then(c => c.addAll(START)).then(() => self.skipWaiting()));
}});
self.addEventListener('activate', event => {{
  event.waitUntil(caches.keys().then(keys => Promise.all(keys
    .filter(key => key.startsWith(PREFIX) && key !== CACHE)
    .map(key => caches.delete(key)))).then(() => self.clients.claim()));
}});
self.addEventListener('fetch', event => {{
  const r = event.request;
  if (r.method !== 'GET' || new URL(r.url).origin !== self.location.origin) return;
  const isNav = r.mode === 'navigate';
  event.respondWith((async () => {{
    const cache = await caches.open(CACHE);
    if (isNav) {{
      try {{ const response = await fetch(r); if (response.ok) cache.put('index.html', response.clone()); return response; }}
      catch (e) {{ return (await cache.match('index.html')) || Response.error(); }}
    }}
    const cached = await cache.match(r);
    if (cached) return cached;
    try {{
      const response = await fetch(r);
      if (response.ok && response.type === 'basic') cache.put(r, response.clone());
      return response;
    }} catch(e) {{ return Response.error(); }}
  }})());
}});
'''
    (OUT/'pg-pwa-sw.js').write_text(js, encoding='utf8')
    print('PWA release ready:', OUT)
    print('Offline cache version:',version)
    print('Use HTTPS hosting to test iPhone Add to Home Screen; file:// cannot run Flutter PWA.')

if __name__=='__main__':
    try: main()
    except Exception as e: print('ERROR:',e,file=sys.stderr);sys.exit(1)
