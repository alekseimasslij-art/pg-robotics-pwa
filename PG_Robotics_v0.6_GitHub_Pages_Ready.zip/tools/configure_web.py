#!/usr/bin/env python3
"""Apply PG brand to the Flutter-generated web platform; keep SDK bootstrap intact."""
from pathlib import Path
import html
import json
import re
import shutil
import sys
ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / 'web'
INDEX = WEB / 'index.html'


def main():
    if not INDEX.exists():
        raise RuntimeError('Run flutter create --platforms=web . before configure_web.py')
    text = INDEX.read_text(encoding='utf8')
    text = re.sub(r'<title>.*?</title>', '<title>PG Robotics</title>', text,
                  flags=re.I | re.S)
    for meta in ('name="apple-mobile-web-app-capable"', 'name="mobile-web-app-capable"',
                 'name="apple-mobile-web-app-status-bar-style"', 'name="theme-color"'):
        text = re.sub(r'\s*<meta\s+' + re.escape(meta) + r'[^>]*>', '', text, flags=re.I)
    injection = '''
  <meta name="theme-color" content="#0A0B0D">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-title" content="PG Robotics">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="description" content="PG Robotics — продукція, новини та аркадна місія">
'''
    if 'name="theme-color"' not in text:
        text = text.replace('</head>', injection + '</head>')
    if 'rel="manifest"' not in text:
        text = text.replace('</head>', '  <link rel="manifest" href="manifest.json">\n</head>')
    if 'rel="apple-touch-icon"' not in text:
        text = text.replace('</head>', '  <link rel="apple-touch-icon" href="apple-touch-icon.png">\n</head>')
    if 'pg-pwa-sw.js' not in text:
        sw = '''
  <script>
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', function() {
        navigator.serviceWorker.register('pg-pwa-sw.js').catch(function(e) {
          console.warn('PG PWA offline caching unavailable:', e);
        });
      });
    }
  </script>
'''
        text = text.replace('</body>', sw + '</body>')
    INDEX.write_text(text, encoding='utf8')
    icon_source = ROOT / 'tools/web_branding'
    shutil.copy2(icon_source / 'favicon.png', WEB / 'favicon.png')
    shutil.copy2(icon_source / 'apple-touch-icon.png', WEB / 'apple-touch-icon.png')
    # Preserve the source brand mark; do not draw product images.
    for name in ('Icon-192.png', 'Icon-512.png', 'Icon-maskable-192.png',
                 'Icon-maskable-512.png'):
        target = WEB / 'icons' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(icon_source / name, target)
    manifest = {
        'name': 'PG Robotics', 'short_name': 'PG Robotics',
        'start_url': '.', 'scope': '.', 'display': 'standalone',
        'background_color': '#0A0B0D', 'theme_color': '#0A0B0D',
        'orientation': 'portrait',
        'description': 'Продукція, новини та інтерактивна місія PG Robotics',
        'icons': [
            {'src':'icons/Icon-192.png','sizes':'192x192','type':'image/png'},
            {'src':'icons/Icon-512.png','sizes':'512x512','type':'image/png'},
            {'src':'icons/Icon-maskable-192.png','sizes':'192x192','type':'image/png','purpose':'maskable'},
            {'src':'icons/Icon-maskable-512.png','sizes':'512x512','type':'image/png','purpose':'maskable'}
        ]
    }
    (WEB/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf8')
    print('Web branding, icon, standalone manifest, and service worker registration: ready')


if __name__ == '__main__':
    try: main()
    except Exception as e: print('ERROR:', e, file=sys.stderr); sys.exit(1)
