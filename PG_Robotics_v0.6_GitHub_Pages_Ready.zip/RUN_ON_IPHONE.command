#!/bin/zsh
cd "$(dirname "$0")"
exec ./RUN_RELEASE.command
