import 'dart:math' as math;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'main.dart';

// Fictional arcade, not a representation of real UAV capabilities or tactics.
// All entities use normalised coordinates, so touch and game logic are shared by iOS and web.
class MissionGameView extends StatefulWidget {
  const MissionGameView({super.key, required this.ukrainian, required this.active});
  final bool ukrainian;
  final bool active;
  @override
  State<MissionGameView> createState() => _MissionGameViewState();
}

class _Enemy {
  _Enemy({required this.x, required this.y, required this.kind,
    required this.speed, required this.phase, required this.hp});
  double x, y, speed, phase;
  final int kind; // 0 scout, 1 zigzag, 2 armored, 3 elite
  int hp;
  double age = 0;
  double get radius => kind == 3 ? .074 : kind == 2 ? .058 : .045;
}
class _Bullet {
  _Bullet(this.x, this.y, this.dx, this.dy, this.pierce);
  double x, y, dx, dy;
  int pierce;
}
class _Drop {
  _Drop(this.x, this.y, this.kind, [this.model = 0]);
  double x, y;
  final int kind; // 0 model blueprint, 1 repair, 2 ammo, 3 shield
  final int model;
}
class _Burst {
  _Burst(this.x, this.y, this.ttl, this.tint);
  double x, y, ttl;
  final Color tint;
}

class _MissionGameViewState extends State<MissionGameView>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  static const _scoreKey = 'pg_mission_best_v2';
  static const _tierKey = 'pg_mission_best_tier_v2';
  final _rnd = math.Random();
  final ValueNotifier<int> _paintFrame = ValueNotifier<int>(0);
  double _lastHudRefresh = 0;
  late AnimationController _engine;
  final List<_Enemy> _enemies = [];
  final List<_Bullet> _bullets = [];
  final List<_Drop> _drops = [];
  final List<_Burst> _bursts = [];
  bool _running = false, _started = false, _gameOver = false;
  int _score = 0, _best = 0, _lives = 3, _tier = 0, _bestTier = 0;
  double _ammoBoost = 0;
  String _feedback = '';
  double _feedbackUntil = 0;
  double _playerX = .5, _playerY = .79;
  double _elapsed = 0, _spawnTimer = 0, _fireTimer = 0, _dropTimer = 0, _invulnerable = 0;
  DateTime? _prev;

  static const _names = ['PG Scout', 'LuckyStrike', 'LuckyShot', 'LuckyStrike-2'];
  String get _name => _names[_tier];
  String get _featureUa => ['Базовий імпульс', 'Подвійне пробиття',
    'Швидка серія', 'Широкий огляд'][_tier];
  String get _featureEn => ['Pulse shot', 'Piercing shot',
    'Rapid volley', 'Wide field'][_tier];
  int get _wave => (_elapsed / 19).floor() + 1;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted && widget.active) _start(fresh: true); });
    _engine = AnimationController(vsync: this, duration: const Duration(minutes: 30))
      ..addListener(_tick);
    _load();
  }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _best = p.getInt(_scoreKey) ?? 0;
      _bestTier = p.getInt(_tierKey) ?? 0;
    });
  }
  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt(_scoreKey, _best);
    await p.setInt(_tierKey, _bestTier);
  }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed) _pause();
  }
  @override
  void didUpdateWidget(covariant MissionGameView old) {
    super.didUpdateWidget(old);
    if (old.active && !widget.active) _pause();
  }
  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _engine.dispose();
    _paintFrame.dispose();
    super.dispose();
  }

  void _start({bool fresh = false}) {
    if (fresh || !_started || _gameOver) {
      _enemies.clear(); _bullets.clear(); _drops.clear(); _bursts.clear();
      _score = 0; _lives = 3; _tier = 0;
      _ammoBoost = 0; _feedback = ''; _elapsed = 0; _spawnTimer = 0;
      _fireTimer = 0; _dropTimer = 0; _invulnerable = 0;
      _playerX = .5; _playerY = .79; _lastHudRefresh = 0;
    }
    _prev = DateTime.now();
    HapticFeedback.selectionClick();
    setState(() { _started = true; _gameOver = false; _running = true; });
    _engine.repeat();
  }
  void _pause() {
    if (!_running) return;
    _engine.stop();
    _save();
    if (mounted) setState(() => _running = false);
  }
  void _die() {
    _engine.stop(); _running = false; _gameOver = true;
    if (_score > _best) _best = _score;
    _save();
    HapticFeedback.heavyImpact();
    if (mounted) setState(() {});
  }
  void _move(Offset pos, Size size) {
    if (!_running || size.width == 0 || size.height == 0) return;
    final scale = _tier == 3 ? .82 : 1.0;
    _playerX = (.5 + (pos.dx / size.width - .5) / scale).clamp(.075, .925).toDouble();
    _playerY = (.5 + (pos.dy / size.height - .5) / scale).clamp(.095, .91).toDouble();
    _paintFrame.value++;
  }
  void _damage() {
    if (_invulnerable > 0) return;
    _lives--;
    if (_tier > 0) _tier--; // damage can downgrade a model.
    _feedback = widget.ukrainian ? 'Пошкодження — рівень знижено' : 'Damaged — model downgraded';
    _feedbackUntil = _elapsed + 1.8;
    _invulnerable = 1.5;
    _bursts.add(_Burst(_playerX, _playerY, .42, const Color(0xFFFF745B)));
    HapticFeedback.mediumImpact();
    if (_lives <= 0) _die();
  }
  void _fire() {
    final y = _playerY - .038;
    if (_tier == 0) {
      _bullets.add(_Bullet(_playerX, y, 0, -.95, 1));
    } else if (_tier == 1) {
      _bullets.add(_Bullet(_playerX, y, 0, -.90, 2));
    } else if (_tier == 2) {
      _bullets.addAll([
        _Bullet(_playerX - .019, y, -.035, -1.12, 1),
        _Bullet(_playerX + .019, y, .035, -1.12, 1),
      ]);
    } else {
      _bullets.addAll([
        _Bullet(_playerX, y, 0, -1.08, 1),
        _Bullet(_playerX, y, -.20, -.99, 1),
        _Bullet(_playerX, y, .20, -.99, 1),
      ]);
    }
    if (_ammoBoost > 0) {
      _bullets.add(_Bullet(_playerX - .031, y, -.12, -.99, 1));
      _bullets.add(_Bullet(_playerX + .031, y, .12, -.99, 1));
    }
    if (_bullets.length > 105) _bullets.removeRange(0, _bullets.length - 105);
  }
  void _spawn() {
    final roll = _rnd.nextDouble();
    final kind = _wave >= 6 && roll < .16 ? 4
      : _wave >= 5 && roll < .29 ? 3
      : _wave >= 3 && roll < .50 ? 2
      : _wave >= 2 && roll < .72 ? 1 : 0;
    _enemies.add(_Enemy(x: .1 + _rnd.nextDouble() * .8, y: -.08,
      kind: kind, phase: _rnd.nextDouble() * math.pi * 2,
      speed: (kind == 4 ? .10 : kind == 3 ? .075 : kind == 2 ? .095 : kind == 1 ? .19 : .155)
        + math.min(_wave * .006, .072),
      hp: kind == 4 ? 12 : kind == 3 ? 7 : kind == 2 ? 4 : 1));
  }
  void _upgrade(int tier) {
    _tier = tier.clamp(0, 3).toInt();
    if (_tier > _bestTier) _bestTier = _tier;
    _feedback = '${widget.ukrainian ? 'Модель' : 'Model'}: ${_names[_tier]}';
    _feedbackUntil = _elapsed + 2.7;
    HapticFeedback.heavyImpact();
    _save();
    _bursts.add(_Burst(_playerX, _playerY, .7, Palette.primary));
  }
  void _collect(_Drop drop) {
    _drops.remove(drop);
    switch (drop.kind) {
      case 0: _upgrade(drop.model); break;
      case 1: _lives = math.min(5, _lives + 1).toInt();
        _feedback = widget.ukrainian ? '+1 життя' : '+1 life'; break;
      case 2: _ammoBoost = 10.0;
        _feedback = widget.ukrainian ? 'Посилені заряди · 10с' : 'Enhanced ammo · 10s'; break;
      case 3: _invulnerable = math.max(_invulnerable, 5.5);
        _feedback = widget.ukrainian ? 'Захисний щит · 5с' : 'Shield · 5s'; break;
    }
    _feedbackUntil = _elapsed + 2.7;
    _score += 5;
    _bursts.add(_Burst(drop.x, drop.y, .6, const Color(0xFF60E0C1)));
    HapticFeedback.lightImpact();
  }
  void _tick() {
    if (!mounted || !_running || !widget.active) return;
    final now = DateTime.now();
    final dt = _prev == null ? .016
        : (now.difference(_prev!).inMicroseconds / 1e6).clamp(0.0, .042).toDouble();
    _prev = now;
    if (dt <= 0) return;
    _elapsed += dt; _spawnTimer += dt; _fireTimer += dt; _dropTimer += dt;
    _invulnerable = math.max(0.0, _invulnerable - dt);
    _ammoBoost = math.max(0.0, _ammoBoost - dt);
    final fireRate = _tier == 2 ? .115 : _tier == 3 ? .23 : _tier == 1 ? .31 : .28;
    if (_fireTimer >= fireRate) { _fireTimer = 0; _fire(); }
    if (_spawnTimer >= math.max(.27, .91 - _wave * .095)) {
      _spawnTimer = 0;
      if (_enemies.length < 28) _spawn();
    }
    // Guaranteed upgrades periodically, with other collectible types mixed in.
    if (_dropTimer >= 12.5) {
      _dropTimer = 0;
      final k = _rnd.nextDouble() < .60 ? 0 : 1 + _rnd.nextInt(3);
      _drops.add(_Drop(.12 + _rnd.nextDouble() * .76, -.06, k,
          1 + _rnd.nextInt(3))); // Switching models can increase OR decrease power.
    }
    for (final b in _bullets) { b.x += b.dx * dt; b.y += b.dy * dt; }
    _bullets.removeWhere((b) => b.y < -.1 || b.x < -.1 || b.x > 1.1 || b.pierce <= 0);
    for (final e in _enemies) {
      e.age += dt;
      e.y += e.speed * dt;
      if (e.kind == 1) e.x += math.sin(e.age * 6 + e.phase) * dt * .25;
      if (e.kind == 3 || e.kind == 4) e.x += math.sin(e.age * 2 + e.phase) * dt * .14;
      e.x = e.x.clamp(.06, .94).toDouble();
    }
    for (final d in _drops) d.y += dt * .18;
    for (final s in _bursts) s.ttl -= dt;
    _bursts.removeWhere((s) => s.ttl < 0);

    for (final e in List<_Enemy>.of(_enemies)) {
      bool destroyed = false;
      for (final b in List<_Bullet>.of(_bullets)) {
        if ((b.x - e.x).abs() < e.radius && (b.y - e.y).abs() < e.radius * .84) {
          b.pierce--;
          e.hp--;
          if (e.hp <= 0) {
            _score += e.kind == 4 ? 150 : e.kind == 3 ? 90 : e.kind == 2 ? 30 : e.kind == 1 ? 15 : 10;
            _bursts.add(_Burst(e.x, e.y, .52, const Color(0xFFFFD557)));
            _enemies.remove(e);
            if (_rnd.nextDouble() < .085 && _drops.length < 4) {
              _drops.add(_Drop(e.x, e.y, _rnd.nextBool() ? 1 : 2));
            }
            destroyed = true;
          }
          break;
        }
      }
      if (destroyed) continue;
      if ((e.x - _playerX).abs() < e.radius + .035 &&
          (e.y - _playerY).abs() < e.radius + .038) {
        _enemies.remove(e); _damage();
      } else if (e.y > 1.09) {
        _enemies.remove(e); _damage();
      }
    }
    for (final d in List<_Drop>.of(_drops)) {
      if ((d.x - _playerX).abs() < .07 && (d.y - _playerY).abs() < .07) {
        _collect(d);
      } else if (d.y > 1.06) {
        _drops.remove(d);
      }
    }
    if (_score > _best) _best = _score;
    _paintFrame.value++;
    // Keep the game painter at vsync while HUD rebuilds only about 7 times/sec.
    if (_elapsed - _lastHudRefresh > .14 && mounted) {
      _lastHudRefresh = _elapsed;
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final ua = widget.ukrainian;
    final size = MediaQuery.sizeOf(context);
    return Material(color: Palette.background, child: SafeArea(
      top: true, bottom: true,
      child: Column(children: [
        Container(
          padding: const EdgeInsets.fromLTRB(12, 6, 12, 8),
          decoration: const BoxDecoration(color: Palette.background,
            border: Border(bottom: BorderSide(color: Palette.border))),
          child: Column(children: [
            Row(children: [
              IconButton(onPressed: () { _pause(); Navigator.of(context).pop(); },
                icon: const Icon(CupertinoIcons.xmark_circle_fill,
                  color: Palette.foreground, size: 26),
                tooltip: ua ? 'Закрити гру' : 'Close game'),
              const SizedBox(width: 4),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(_name, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
                Text(ua ? _featureUa : _featureEn,
                  style: const TextStyle(color: Palette.secondary, fontSize: 10)),
              ])),
              Text('♥ $_lives   ◈ ${_invulnerable > 0 ? 'ON' : '–'}',
                style: const TextStyle(color: Palette.primary, fontWeight: FontWeight.w900,
                  fontSize: 13)),
              IconButton(onPressed: _running ? _pause : _gameOver ? null : () => _start(),
                icon: Icon(_running ? CupertinoIcons.pause_fill : CupertinoIcons.play_fill,
                color: Palette.primary)),
            ]),
            Row(children: [
              Expanded(child: Text('${ua ? 'ХВИЛЯ' : 'WAVE'} $_wave',
                style: const TextStyle(fontSize: 11, color: Palette.secondary))),
              Text('${ua ? 'ОЧКИ' : 'SCORE'} $_score  ·  ${ua ? 'РЕКОРД' : 'BEST'} $_best',
                style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
            ]),
          ]),
        ),
        Expanded(child: LayoutBuilder(builder: (context, constraints) {
          final bounds = Size(constraints.maxWidth, constraints.maxHeight);
          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onPanDown: (d) => _move(d.localPosition, bounds),
            onPanUpdate: (d) => _move(d.localPosition, bounds),
            onTapDown: (d) => _move(d.localPosition, bounds),
            child: Stack(fit: StackFit.expand, children: [
              const RepaintBoundary(child: _MissionBackground()),
              RepaintBoundary(child: AnimatedBuilder(animation: _paintFrame,
                builder: (_, __) => CustomPaint(painter: _MissionPainter(
                  enemies: _enemies, bullets: _bullets, drops: _drops,
                  bursts: _bursts, player: Offset(_playerX, _playerY),
                  elapsed: _elapsed, tier: _tier,
                  shield: _invulnerable > 0, ammoBoost: _ammoBoost > 0,
                )))),
              if (_running && _elapsed < _feedbackUntil)
                Positioned(top: 20, left: 14, right: 14,
                  child: IgnorePointer(child: Center(child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(color: const Color(0xE9111B1D),
                      border: Border.all(color: Palette.primary),
                      borderRadius: BorderRadius.circular(13)),
                    child: Text(_feedback, textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800,
                        color: Palette.primary)))))),
              if (!_running) ColoredBox(color: const Color(0xD1090B0D),
                child: Center(child: Padding(padding: const EdgeInsets.all(24),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Icon(_gameOver ? CupertinoIcons.refresh_circled : CupertinoIcons.pause_circle,
                      color: Palette.primary, size: 54),
                    const SizedBox(height: 15),
                    Text(_gameOver ? (ua ? 'МІСІЮ ЗАВЕРШЕНО' : 'MISSION OVER') : (ua ? 'ПАУЗА' : 'PAUSED'),
                      textAlign: TextAlign.center, style: const TextStyle(fontSize: 25,
                        fontWeight: FontWeight.w900)),
                    const SizedBox(height: 12),
                    Text(_gameOver ? '${ua ? 'Очки' : 'Score'}: $_score' :
                      (ua ? 'Рухай пальцем у будь-якому напрямку' : 'Move your finger in any direction'),
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Palette.secondary)),
                    const SizedBox(height: 18),
                    YellowAction(title: _gameOver ? (ua ? 'Заново' : 'Restart') :
                      (ua ? 'Продовжити' : 'Resume'), onTap: () => _start(fresh: _gameOver),
                      icon: CupertinoIcons.play_fill),
                  ])))),
            ]),
          );
        })),
        Container(
          padding: EdgeInsets.only(left: 15, right: 15, top: 6,
            bottom: size.height < 700 ? 1 : 7),
          child: Text(ua ? 'Підбирай моделі, ремонти, щити й боєприпаси. Втрата життя може знизити рівень.' :
            'Collect models, repairs, shields and ammunition. Damage may downgrade the model.',
            maxLines: 2, textAlign: TextAlign.center,
            style: const TextStyle(color: Palette.secondary, fontSize: 10)),
        ),
      ]),
    ));
  }

}

class _Stat extends StatelessWidget {
  const _Stat(this.label, this.value);
  final String label, value;
  @override
  Widget build(BuildContext context) => Expanded(child: Container(
    height: 52, padding: const EdgeInsets.fromLTRB(10, 8, 4, 6),
    decoration: BoxDecoration(color: Palette.surface, border: Border.all(color: Palette.border),
      borderRadius: BorderRadius.circular(11)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Text(label, style: const TextStyle(fontSize: 9, color: Palette.secondary,
          fontWeight: FontWeight.w700, letterSpacing: .5)),
        Text(value, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
      ]),
  ));
}

class _MissionBackground extends StatelessWidget {
  const _MissionBackground();
  @override
  Widget build(BuildContext context) => CustomPaint(
    painter: _MissionBackdropPainter());
}
class _MissionBackdropPainter extends CustomPainter {
  const _MissionBackdropPainter();
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..shader = const LinearGradient(
      begin: Alignment.topCenter, end: Alignment.bottomCenter,
      colors: [Color(0xFF1D3037), Color(0xFF0D141B), Color(0xFF0A1014)],
    ).createShader(Offset.zero & size));
    final paint = Paint()..color = const Color(0x12FFDE19)..strokeWidth = .6;
    for (double x = 0; x < size.width; x += 39) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
  }
  @override
  bool shouldRepaint(covariant _MissionBackdropPainter old) => false;
}

class _MissionPainter extends CustomPainter {
  const _MissionPainter({required this.enemies, required this.bullets,
    required this.drops, required this.bursts, required this.player,
    required this.elapsed, required this.tier, required this.ammoBoost,
    required this.shield});
  final List<_Enemy> enemies;
  final List<_Bullet> bullets;
  final List<_Drop> drops;
  final List<_Burst> bursts;
  final Offset player;
  final double elapsed;
  final int tier;
  final bool ammoBoost, shield;
  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width, h = size.height;

    final gridPaint = Paint()..color = const Color(0x1BFFDE19)..strokeWidth = .65;
    final spacing = tier == 3 ? 25.0 : 39.0; // Wide view simulates a larger field.
    final yOffset = (elapsed * 32) % spacing;
    // Static vertical lines belong to the background layer.

    for (double y = -spacing; y < h; y += spacing) {
      canvas.drawLine(Offset(0, y + yOffset), Offset(w, y + yOffset), gridPaint);
    }
    canvas.drawLine(Offset(w * .5, 0), Offset(w * .5, h),
      Paint()..color = const Color(0x22FFDE19)..strokeWidth = 1);
    final factor = tier == 3 ? .82 : 1.0;
    Offset pt(double x, double y) => Offset(w * (.5 + (x - .5) * factor),
      h * (.5 + (y - .5) * factor));
    canvas.save(); canvas.clipRect(Offset.zero & size);
    for (final d in drops) {
      final p = pt(d.x, d.y);
      final yellow = d.kind == 0;
      final color = yellow ? Palette.primary : const Color(0xFF65E7C9);
      canvas.drawCircle(p, 17 * factor, Paint()..color = color.withValues(alpha: .18));
      final diamond = Path()..moveTo(p.dx, p.dy - 11 * factor)
        ..lineTo(p.dx + 11 * factor, p.dy)
        ..lineTo(p.dx, p.dy + 11 * factor)
        ..lineTo(p.dx - 11 * factor, p.dy)..close();
      canvas.drawPath(diamond, Paint()..color = color);
      final symbols = [(['?', 'LS', 'SHOT', 'LS2'][d.model]), '♥', '▲', '◈'];
      final symbol = TextPainter(text: TextSpan(text: symbols[d.kind],
        style: const TextStyle(color: Color(0xFF091113), fontSize: 12,
          fontWeight: FontWeight.w900)), textDirection: TextDirection.ltr)..layout();
      symbol.paint(canvas, p - Offset(symbol.width / 2, symbol.height / 2));
    }
    for (final b in bullets) {
      final p = pt(b.x, b.y);
      canvas.drawLine(p + Offset(0, 6 * factor), p - Offset(0, 10 * factor),
          Paint()..color = (ammoBoost ? const Color(0xFF7EEAFF) : const Color(0xFFFFDE19))..strokeWidth = (ammoBoost ? 5 : 3) * factor
            ..strokeCap = StrokeCap.round);
    }
    for (final e in enemies) {
      final p = pt(e.x, e.y);
      final s = factor * (e.kind >= 4 ? 1.6 : e.kind == 3 ? 1.45 : e.kind == 2 ? 1.18 : 1);
      canvas.save(); canvas.translate(p.dx, p.dy); canvas.scale(s);
      final base = e.kind == 4 ? const Color(0xFFAA8FFF) : e.kind == 3 ? const Color(0xFFE76EAA)
        : e.kind == 2 ? const Color(0xFFFFA650)
        : e.kind == 1 ? const Color(0xFF67B6FF)
        : const Color(0xFFFF775D);
      if (e.kind >= 2) canvas.drawCircle(Offset.zero, 20,
        Paint()..color = base.withValues(alpha: .13));
      final armPaint = Paint()..color = const Color(0xFF8598A0)
        ..strokeWidth = 3.2..strokeCap = StrokeCap.round;
      canvas.drawLine(const Offset(-16, -12), const Offset(16, 12), armPaint);
      canvas.drawLine(const Offset(16, -12), const Offset(-16, 12), armPaint);
      for (final x in [-17.0, 17.0]) {
        for (final y in [-13.0, 13.0]) {
          canvas.drawCircle(Offset(x, y), 5, Paint()..color = base
            ..style = PaintingStyle.stroke..strokeWidth = 2);
        }
      }
      final shape = Path()..moveTo(0, 15)..lineTo(-9, 0)..lineTo(0, -15)
        ..lineTo(9, 0)..close();
      canvas.drawPath(shape, Paint()..color = base);
      if (e.kind == 4) {
        canvas.drawCircle(Offset.zero, 25, Paint()..color = const Color(0xFF78DAFF)
          ..style = PaintingStyle.stroke..strokeWidth = 3);
      }
      if (e.kind >= 2) {
        canvas.drawCircle(Offset.zero, 3, Paint()..color = Colors.black);
      }
      canvas.restore();
    }
    for (final s in bursts) {
      final p = pt(s.x, s.y);
      final f = (s.ttl / .7).clamp(0.0, 1.0);
      canvas.drawCircle(p, (1 - f) * 32 + 8, Paint()
        ..color = s.tint.withValues(alpha: f)..strokeWidth = 2.2
        ..style = PaintingStyle.stroke);
    }
    final p = pt(player.dx, player.dy);
    _drawPlayer(canvas, p, factor);
    if (shield) canvas.drawCircle(p, 31 * factor, Paint()
      ..color = const Color(0xFF65E7C9).withValues(alpha: .7)
      ..strokeWidth = 2..style = PaintingStyle.stroke);
    canvas.restore();
  }
  void _drawPlayer(Canvas canvas, Offset p, double s) {
    canvas.save(); canvas.translate(p.dx, p.dy); canvas.scale(s);
    final paintColor = [const Color(0xFFFFDE19), const Color(0xFFE3CF88),
      const Color(0xFF8FE7F6), const Color(0xFFBBA9FF)][tier];
    canvas.drawCircle(Offset.zero, 30, Paint()..color = paintColor.withValues(alpha: .11));
    final arms = Paint()..color = paintColor
      ..strokeWidth = 4..strokeCap = StrokeCap.round;
    canvas.drawLine(const Offset(-20, -14), const Offset(20, 14), arms);
    canvas.drawLine(const Offset(20, -14), const Offset(-20, 14), arms);
    for (final x in [-22.0, 22.0]) {
      for (final y in [-16.0, 16.0]) {
        canvas.drawCircle(Offset(x, y), 6, Paint()..color = paintColor
          ..style = PaintingStyle.stroke..strokeWidth = 2);
      }
    }
    final body = tier == 1
      ? (Path()..moveTo(0, -28)..lineTo(15, 1)..lineTo(10, 14)
        ..lineTo(-10, 14)..lineTo(-15, 1)..close())
      : tier == 2 ? (Path()..moveTo(0, -23)..lineTo(17, -4)
        ..lineTo(15, 15)..lineTo(0, 8)..lineTo(-15, 15)..lineTo(-17, -4)..close())
      : tier == 3 ? (Path()..moveTo(0, -27)..lineTo(21, -10)
        ..lineTo(11, 17)..lineTo(0, 11)..lineTo(-11, 17)..lineTo(-21, -10)..close())
      : (Path()..moveTo(0, -24)..lineTo(11, 5)
        ..lineTo(0, 18)..lineTo(-11, 5)..close());
    canvas.drawPath(body, Paint()..color = paintColor);
    canvas.drawCircle(const Offset(0, 1), 3, Paint()..color = Colors.black);
    canvas.restore();
  }
  @override
  bool shouldRepaint(covariant _MissionPainter oldDelegate) => true;
}

/// Lightweight tab hub. The engine is created only when the modal is visible.
class MissionScreen extends StatelessWidget {
  const MissionScreen({super.key, required this.ukrainian, required this.active});
  final bool ukrainian, active;
  @override
  Widget build(BuildContext context) {
    final ua = ukrainian;
    return ListView(padding: const EdgeInsets.fromLTRB(22, 29, 22, 28), children: [
      const Kicker('PG / ARCADE'),
      const SizedBox(height: 12),
      Text(ua ? 'Місія: Небо' : 'Mission: Sky',
        style: const TextStyle(fontSize: 33, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      Text(ua ? 'Міні-гра з повноекранним керуванням, моделями та бонусами.' :
        'A full-screen arcade with collectible models and rewards.',
        style: const TextStyle(color: Palette.secondary, height: 1.5)),
      const SizedBox(height: 24),
      Container(height: 290, decoration: BoxDecoration(
        border: Border.all(color: Palette.border),
        borderRadius: BorderRadius.circular(22),
        gradient: const LinearGradient(colors: [Color(0xFF25313A), Color(0xFF0C1219)])),
        child: Stack(children: [
          const Positioned.fill(child: IgnorePointer(child: _MissionBackground())),
          const Center(child: Icon(Icons.flight_takeoff_rounded,
            size: 90, color: Color(0x88FFDE19))),
          Center(child: Material(color: Palette.primary,
            shape: const CircleBorder(),
            child: InkWell(customBorder: const CircleBorder(), onTap: () => _openGame(context),
              child: const SizedBox(width: 96, height: 96,
                child: Icon(CupertinoIcons.play_fill, size: 38, color: Palette.background))))),
          Positioned(bottom: 20, left: 15, right: 15,
            child: Text(ua ? 'НАТИСНИ PLAY, ЩОБ РОЗПОЧАТИ' : 'TAP PLAY TO START',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 11, letterSpacing: 1.4,
                fontWeight: FontWeight.w900, color: Palette.primary))),
        ])),
      const SizedBox(height: 23),
      Text(ua ? 'Доступні моделі' : 'Available models',
        style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
      const SizedBox(height: 14),
      for (final m in const [
        ('PG Scout','Базова модель · 1 заряд'),
        ('LuckyStrike','Проникний заряд'),
        ('LuckyShot','Висока швидкість стрільби'),
        ('LuckyStrike-2','Широкий сектор'),
      ]) Padding(padding: const EdgeInsets.only(bottom: 8), child: Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(color: Palette.surface,
          border: Border.all(color: Palette.border),
          borderRadius: BorderRadius.circular(13)),
        child: Row(children: [
          const Icon(Icons.airplanemode_active, color: Palette.primary),
          const SizedBox(width: 13),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(m.$1, style: const TextStyle(fontWeight: FontWeight.w800)),
            Text(m.$2, style: const TextStyle(color: Palette.secondary,fontSize: 11)),
          ])),
        ]))),
      const SizedBox(height: 7),
      Text(ua ? 'Ігрові здібності вигадані й не є технічними характеристиками продукції.' :
        'Arcade abilities are fictional and are not product specifications.',
        style: const TextStyle(color: Palette.tertiary, fontSize: 11)),
    ]);
  }
  void _openGame(BuildContext context) {
    HapticFeedback.mediumImpact();
    Navigator.of(context).push(PageRouteBuilder<void>(
      opaque: true,
      transitionDuration: const Duration(milliseconds: 320),
      reverseTransitionDuration: const Duration(milliseconds: 240),
      pageBuilder: (context, _, __) => MissionGameView(ukrainian: ukrainian, active: true),
      transitionsBuilder: (_, animation, __, child) => SlideTransition(
        position: Tween(begin: const Offset(0, 1), end: Offset.zero)
          .animate(CurvedAnimation(parent: animation, curve: Curves.easeOutCubic)),
        child: child),
    ));
  }
}
