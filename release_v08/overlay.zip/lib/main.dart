import 'package:pg_robotics_app/mission_game.dart';
import 'package:pg_robotics_app/contact_actions.dart';
import 'package:pg_robotics_app/news_sheet.dart';

import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarBrightness: Brightness.dark,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Palette.background,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const PgRoboticsApp());
}

/// Brand palette is a design approximation until PG Robotics supplies its brandbook.
abstract final class Palette {
  static const background = Color(0xFF0A0B0D);
  static const surface = Color(0xFF17191B);
  static const surfaceRaised = Color(0xFF212326);
  static const border = Color(0xFF303235);
  static const primary = Color(0xFFFFDE19);
  static const foreground = Color(0xFFF4F3EF);
  static const secondary = Color(0xFF9A9C9F);
  static const tertiary = Color(0xFF676B6E);
}

String localized(bool ua, String ukrainian, String english) =>
    ua ? ukrainian : english;

class PgRoboticsApp extends StatelessWidget {
  const PgRoboticsApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'PG Robotics',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: Palette.background,
          fontFamily: '.SF Pro Text', // Falls back to the iOS system font.
          colorScheme: const ColorScheme.dark(
            primary: Palette.primary,
            surface: Palette.surface,
            onPrimary: Palette.background,
            onSurface: Palette.foreground,
          ),
          iconTheme: const IconThemeData(color: Palette.foreground),
          splashFactory: InkRipple.splashFactory,
          textTheme: const TextTheme(
            bodyMedium: TextStyle(color: Palette.foreground),
          ),
        ),
        home: const MainShell(),
      );
}

class ProductInfo {
  const ProductInfo({
    required this.id,
    required this.name,
    required this.position,
    required this.image,
    required this.subtitleUa,
    required this.subtitleEn,
    required this.bodyUa,
    required this.bodyEn,
  });
  final String id;
  final String name;
  final String position;
  final String image;
  final String subtitleUa;
  final String subtitleEn;
  final String bodyUa;
  final String bodyEn;
}

const allProducts = <ProductInfo>[
  ProductInfo(
    id: 'luckystrike',
    name: 'LuckyStrike',
    position: '01',
    image: 'assets/images/luckystrike.jpg',
    subtitleUa: 'Безпілотна платформа',
    subtitleEn: 'Unmanned platform',
    bodyUa: 'Одна з платформ PG Robotics. У цьому розділі представлено огляд моделі та її офіційні матеріали.',
    bodyEn: 'One of the PG Robotics platforms. This page presents a model overview and its official media.',
  ),
  ProductInfo(
    id: 'luckystrike2',
    name: 'LuckyStrike-2',
    position: '02',
    image: 'assets/images/luckystrike2.jpg',
    subtitleUa: 'Багатофункціональна система',
    subtitleEn: 'Multifunctional system',
    bodyUa: 'Модель із лінійки PG Robotics. Цей екран призначений для презентації зображень та основної інформації про продукт.',
    bodyEn: 'A PG Robotics model. This screen is intended for photographs and general product information.',
  ),
  ProductInfo(
    id: 'luckyshot',
    name: 'LuckyShot',
    position: '03',
    image: 'assets/images/luckyshot.jpg',
    subtitleUa: 'Розробка PG Robotics',
    subtitleEn: 'PG Robotics engineering',
    bodyUa: 'Інформаційна сторінка моделі. Оригінальні фотографії додаються до проєкту як локальні ресурси.',
    bodyEn: 'A model information page. Original photographs are included in the project as local assets.',
  ),
  ProductInfo(
    id: 'uavkit',
    name: 'UAV Kit',
    position: '04',
    image: 'assets/images/uavkit.jpg',
    subtitleUa: 'Комплекти та обладнання',
    subtitleEn: 'Equipment and kits',
    bodyUa: 'Розділ обладнання та комплектів. Сторінка має демонстраційний характер, без купівлі або замовлення.',
    bodyEn: 'Equipment and kits section. This page is informational, with no purchase or ordering functionality.',
  ),
];

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell>
    with SingleTickerProviderStateMixin {
  late final AnimationController _tabReveal;

  @override
  void initState() {
    super.initState();
    _tabReveal = AnimationController(vsync: this,
      duration: Duration(milliseconds: kIsWeb ? 110 : 240), value: 1);
    _loadNews();
  }

  @override
  void dispose() {
    _tabReveal.dispose();
    super.dispose();
  }

  int _selectedTab = 0;
  bool _ukrainian = true;
  List<NewsItem> _news = const [];
  Set<String> _seenNews = <String>{};
  bool _newsOpen = false;

  Future<void> _loadNews() async {
    try {
      final entries = await DemoNewsStore.load();
      final seen = await DemoNewsStore.seen();
      if (mounted) setState(() { _news = entries; _seenNews = seen; });
    } catch (_) {
      // App remains fully usable if demo news assets are missing.
    }
  }

  Future<void> _openNews() async {
    HapticFeedback.selectionClick();
    setState(() => _newsOpen = true);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: const Color(0xC4000000),
      useSafeArea: true,
      builder: (_) => NewsSheet(
        ukrainian: _ukrainian,
        items: _news,
        seen: _seenNews,
        onSeenChanged: (seen) {
          if (mounted) setState(() => _seenNews = seen);
        },
      ),
    );
    if (mounted) setState(() => _newsOpen = false);
  }

  void _setTab(int tab) {
    if (tab == _selectedTab) return;
    HapticFeedback.selectionClick();
    setState(() => _selectedTab = tab);
    _tabReveal.forward(from: 0);
  }

  void _showProduct(ProductInfo item) {
    HapticFeedback.lightImpact();
    Navigator.of(context).push(CupertinoPageRoute<void>(
      builder: (_) => ProductDetail(product: item, ukrainian: _ukrainian),
    ));
  }

  @override
  Widget build(BuildContext context) {
    // IMPORTANT: Only the selected page is painted. The old Stack +
    // AnimatedOpacity rendered multiple full-screen pages together on iOS.
    final pages = <Widget>[
      HomeScreen(
        ukrainian: _ukrainian,
        onBrowse: () => _setTab(1),
        onProduct: _showProduct,
        onMission: () => _setTab(2),
        onNews: _openNews,
        onContact: () => _setTab(4),
      ),
      CatalogScreen(ukrainian: _ukrainian, onProduct: _showProduct),
      MissionScreen(ukrainian: _ukrainian, active: _selectedTab == 2 && !_newsOpen),
      CompanyScreen(ukrainian: _ukrainian,
        onBrowse: () => _setTab(1),
        onContact: () => _setTab(4)),
      ContactsScreen(ukrainian: _ukrainian),
    ];

    return Scaffold(
      backgroundColor: Palette.background,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            AppTopBar(
              ukrainian: _ukrainian,
              onHome: () => _setTab(0),
              onLanguage: (bool value) => setState(() => _ukrainian = value),
              onNews: _openNews,
              unread: _news.where((n) => !_seenNews.contains(n.id)).length,
            ),
            Expanded(
              child: ClipRect(
                child: FadeTransition(
                  // Animate ONLY the new visible screen. No outgoing page
                  // remains composited behind it (regression on iOS 26).
                  opacity: Tween(begin: kIsWeb ? 1.0 : .86, end: 1.0).animate(
                      CurvedAnimation(parent: _tabReveal,
                          curve: Curves.easeOutCubic)),
                  child: SlideTransition(
                    position: Tween(begin: kIsWeb ? Offset.zero : const Offset(.028, 0),
                        end: Offset.zero).animate(CurvedAnimation(
                          parent: _tabReveal,
                          curve: Curves.easeOutCubic)),
                    child: RepaintBoundary(child: IndexedStack(
                      index: _selectedTab,
                      sizing: StackFit.expand,
                      children: List.generate(pages.length, (i) =>
                        TickerMode(enabled: i == _selectedTab, child: pages[i])),
                    )),
                  ),
                ),
              ),
            ),
            NativeTabBar(
              selectedTab: _selectedTab,
              ukrainian: _ukrainian,
              onSelect: _setTab,
            ),
          ],
        ),
      ),
    );
  }
}

class AppTopBar extends StatelessWidget {
  const AppTopBar({
    super.key,
    required this.ukrainian,
    required this.onHome,
    required this.onLanguage,
    required this.onNews,
    required this.unread,
  });
  final bool ukrainian;
  final VoidCallback onHome;
  final ValueChanged<bool> onLanguage;
  final VoidCallback onNews;
  final int unread;

  @override
  Widget build(BuildContext context) => Container(
        height: 62,
        decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: Palette.border, width: .6)),
        ),
        padding: const EdgeInsets.fromLTRB(22, 0, 19, 0),
        child: Row(
          children: [
            Expanded(child: GestureDetector(
              onTap: onHome,
              child: Row(
                children: [
                  Container(
                    width: 35,
                    height: 35,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Palette.primary,
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: const Text('PG', style: TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                      color: Palette.background,
                      letterSpacing: -1.4,
                    )),
                  ),
                  const SizedBox(width: 10),
                  const Expanded(child: Text('PG ROBOTICS',
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 14.5,
                      fontWeight: FontWeight.w900,
                      letterSpacing: .9,
                    ))),
                ],
              ),
            )),
            const SizedBox(width: 4),
            Stack(clipBehavior: Clip.none, children: [
              IconButton(
                onPressed: onNews,
                tooltip: ukrainian ? 'Новини та сповіщення' : 'News and alerts',
                icon: const Icon(CupertinoIcons.bell, size: 23,
                    color: Palette.foreground),
              ),
              if (unread > 0) Positioned(top: 1, right: 3,
                child: IgnorePointer(child: Container(
                  height: 16, constraints: const BoxConstraints(minWidth: 16),
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: Palette.primary,
                    borderRadius: BorderRadius.circular(12)),
                  child: Text(unread > 9 ? '9+' : '$unread',
                    style: const TextStyle(color: Palette.background,
                      fontSize: 9, fontWeight: FontWeight.w900)),
                ))),
            ]),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.all(3),
              decoration: BoxDecoration(
                border: Border.all(color: Palette.border),
                color: Palette.surface,
                borderRadius: BorderRadius.circular(30),
              ),
              child: Row(children: [
                _languagePill('UA', ukrainian, () => onLanguage(true)),
                _languagePill('EN', !ukrainian, () => onLanguage(false)),
              ]),
            ),
          ],
        ),
      );

  Widget _languagePill(String text, bool selected, VoidCallback onTap) =>
      GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 240),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          decoration: BoxDecoration(
            color: selected ? Palette.primary : Colors.transparent,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(text, style: TextStyle(
            fontSize: 10,
            color: selected ? Palette.background : Palette.secondary,
            fontWeight: FontWeight.w900,
          )),
        ),
      );
}

class NativeTabBar extends StatelessWidget {
  const NativeTabBar({
    super.key,
    required this.selectedTab,
    required this.ukrainian,
    required this.onSelect,
  });
  final int selectedTab;
  final bool ukrainian;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    final items = [
      (CupertinoIcons.house_fill, localized(ukrainian, 'Головна', 'Home')),
      (CupertinoIcons.square_grid_2x2_fill,
          localized(ukrainian, 'Продукція', 'Products')),
      (Icons.radar_rounded, localized(ukrainian, 'Місія', 'Mission')),
      (Icons.apartment_rounded, localized(ukrainian, 'Компанія', 'Company')),
      (Icons.chat_bubble_rounded, localized(ukrainian, 'Контакти', 'Contacts')),
    ];
    return ClipRect(
      child: Container(
          decoration: const BoxDecoration(
            color: Color(0xFF151719),
            border: Border(top: BorderSide(color: Palette.border, width: .7)),
          ),
          child: SafeArea(
            top: false,
            child: Padding(
              padding: EdgeInsets.only(bottom: kIsWeb ? 16 : 0),
              child: SizedBox(
              height: 71,
              child: LayoutBuilder(builder: (context, constraints) {
                final step = constraints.maxWidth / items.length;
                return Stack(
                  children: [
                    AnimatedPositioned(
                      duration: const Duration(milliseconds: 340),
                      curve: Curves.easeOutCubic,
                      left: step * selectedTab + step * .5 - 16,
                      top: 0,
                      child: Container(
                        height: 3,
                        width: 32,
                        decoration: BoxDecoration(
                          color: Palette.primary,
                          borderRadius: BorderRadius.circular(5),
                          boxShadow: const [BoxShadow(
                            color: Color(0x55FFDE19), blurRadius: 12,
                          )],
                        ),
                      ),
                    ),
                    Row(children: List.generate(items.length, (index) {
                      final current = selectedTab == index;
                      return Expanded(
                        child: Semantics(
                          button: true,
                          selected: current,
                          label: items[index].$2,
                          child: GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onTap: () => onSelect(index),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                TweenAnimationBuilder<double>(
                                  tween: Tween(end: current ? 1.12 : 1),
                                  curve: Curves.easeOutBack,
                                  duration: const Duration(milliseconds: 260),
                                  builder: (_, factor, child) =>
                                      Transform.scale(scale: factor, child: child),
                                  child: Icon(
                                    items[index].$1,
                                    size: 23,
                                    color: current
                                        ? Palette.primary
                                        : Palette.secondary,
                                  ),
                                ),
                                const SizedBox(height: 7),
                                AnimatedDefaultTextStyle(
                                  duration: const Duration(milliseconds: 220),
                                  style: TextStyle(
                                    fontSize: 10,
                                    height: 1,
                                    fontWeight: current
                                        ? FontWeight.w800
                                        : FontWeight.w600,
                                    color: current
                                        ? Palette.foreground
                                        : Palette.secondary,
                                  ),
                                  child: Text(items[index].$2),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    })),
                  ],
                );
              }),
            )),
          ),
        ),
    );
  }
}

class Padded extends StatelessWidget {
  const Padded({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 21),
        child: child,
      );
}

class Kicker extends StatelessWidget {
  const Kicker(this.label, {super.key});
  final String label;
  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 17, height: 2, color: Palette.primary),
          const SizedBox(width: 8),
          Flexible(
            child: Text(label.toUpperCase(), style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.8,
              color: Palette.primary,
            )),
          ),
        ],
      );
}

class LabelTitle extends StatelessWidget {
  const LabelTitle(this.text, {super.key, this.fontSize = 30});
  final String text;
  final double fontSize;
  @override
  Widget build(BuildContext context) => Text(text,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: FontWeight.w800,
        height: 1.11,
        letterSpacing: -0.8,
      ));
}

class YellowAction extends StatelessWidget {
  const YellowAction({
    super.key,
    required this.title,
    required this.onTap,
    this.icon = CupertinoIcons.arrow_up_right,
  });
  final String title;
  final VoidCallback onTap;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Material(
        borderRadius: BorderRadius.circular(14),
        color: Palette.primary,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(14),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Text(title, style: const TextStyle(
                color: Palette.background,
                fontWeight: FontWeight.w800,
                fontSize: 13,
              )),
              const SizedBox(width: 18),
              Icon(icon, size: 17, color: Palette.background),
            ]),
          ),
        ),
      );
}

/// Demo illustrations are synthetic visual placeholders; replace with official photos.
/// Product imagery must be reviewed before a client production release.
class BrandPhoto extends StatelessWidget {
  const BrandPhoto({
    super.key,
    required this.asset,
    required this.label,
    this.fit = BoxFit.cover,
    this.alignment = Alignment.center,
  });
  final String asset;
  final String label;
  final BoxFit fit;
  final Alignment alignment;

  @override
  Widget build(BuildContext context) => Image.asset(
        asset,
        fit: fit,
        alignment: alignment,
        width: double.infinity,
        height: double.infinity,
        errorBuilder: (_, __, ___) => _PhotoPlaceholder(label: label),
      );
}

class _DemoMediaTag extends StatelessWidget {
  const _DemoMediaTag();
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
    decoration: BoxDecoration(color: const Color(0xE00A0B0D),
      borderRadius: BorderRadius.circular(7)),
    child: const Text('DEMO CONCEPT', style: TextStyle(fontSize: 9,
      letterSpacing: 1.1, color: Palette.primary, fontWeight: FontWeight.w900)));
}

class _PhotoPlaceholder extends StatelessWidget {
  const _PhotoPlaceholder({required this.label});
  final String label;
  @override
  Widget build(BuildContext context) => DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF333537), Color(0xFF141618), Color(0xFF202226)],
          ),
        ),
        child: Stack(children: [
          Positioned(
            top: -105,
            right: -40,
            child: Container(
              height: 290,
              width: 290,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0x18FFFFFF), width: 1),
              ),
            ),
          ),
          Positioned(
            bottom: -120,
            left: -70,
            child: Container(
              width: 290,
              height: 290,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0x12FFFFFF), width: 1),
              ),
            ),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(CupertinoIcons.photo,
                    color: Palette.tertiary, size: 24),
                const SizedBox(height: 12),
                Text(label.toUpperCase(),
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 18,
                      height: 1.1,
                      letterSpacing: 2,
                      color: Color(0xFF8C8F92),
                      fontWeight: FontWeight.w900,
                    )),
              ]),
            ),
          ),
        ]),
      );
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.ukrainian,
    required this.onBrowse, required this.onProduct, required this.onMission,
    required this.onNews, required this.onContact});
  final bool ukrainian;
  final VoidCallback onBrowse, onMission, onNews, onContact;
  final ValueChanged<ProductInfo> onProduct;

  @override
  Widget build(BuildContext context) {
    final ua = ukrainian;
    final featured = allProducts[1];
    return CustomScrollView(
      key: const PageStorageKey('homeScrollV3'),
      physics: const BouncingScrollPhysics(),
      slivers: [SliverPadding(padding: const EdgeInsets.fromLTRB(20, 22, 20, 35),
        sliver: SliverList(delegate: SliverChildListDelegate([
          Row(children: [
            const Icon(CupertinoIcons.circle_fill, color: Palette.primary, size: 8),
            const SizedBox(width: 9),
            Text(ua ? 'ВІТАЄМО У PG ROBOTICS' : 'WELCOME TO PG ROBOTICS',
              style: const TextStyle(color: Palette.secondary,
                fontSize: 10, letterSpacing: 1.4, fontWeight: FontWeight.w800)),
          ]),
          const SizedBox(height: 15),
          Text(ua ? 'Інженерія\nв дії.' : 'Engineering\nin motion.',
            style: const TextStyle(fontSize: 39, fontWeight: FontWeight.w900,
              letterSpacing: -1.7, height: 1.05)),
          const SizedBox(height: 11),
          Text(ua ? 'Продукція, підтримка та новини —\nв одному місці.'
            : 'Products, support and updates —\nall in one place.',
            style: const TextStyle(color: Palette.secondary,
              fontSize: 13, height: 1.5)),
          const SizedBox(height: 23),
          _DashboardTile(onTap: onBrowse,
            height: 150, featured: true, icon: CupertinoIcons.square_grid_2x2_fill,
            kicker: ua ? 'КАТАЛОГ' : 'CATALOG',
            title: ua ? 'Наші розробки' : 'Our products',
            description: ua ? 'Переглянути всі моделі' : 'Explore all models'),
          const SizedBox(height: 11),
          Row(children: [
            Expanded(child: _DashboardTile(
              onTap: onMission, icon: Icons.radar_rounded, height: 140,
              kicker: 'PG / ARCADE',
              title: ua ? 'Місія' : 'Mission',
              description: ua ? 'Грай та покращуй рекорд' : 'Play & beat your best')),
            const SizedBox(width: 11),
            Expanded(child: _DashboardTile(
              onTap: onContact, icon: CupertinoIcons.chat_bubble_text_fill,
              height: 140,
              kicker: ua ? 'НА ЗВ’ЯЗКУ' : 'GET IN TOUCH',
              title: ua ? 'Підтримка' : 'Support',
              description: ua ? 'Зв’язок із командою' : 'Talk to our team')),
          ]),
          const SizedBox(height: 25),
          Row(children: [
            Expanded(child: LabelTitle(ua ? 'У фокусі' : 'Spotlight', fontSize: 23)),
            TextButton(onPressed: onBrowse,
              child: Text(ua ? 'Усі моделі  ↗' : 'All models  ↗',
                style: const TextStyle(color: Palette.primary, fontSize: 12))),
          ]),
          const SizedBox(height: 8),
          Material(color: Palette.surface,
            clipBehavior: Clip.antiAlias,
            borderRadius: BorderRadius.circular(18),
            child: InkWell(onTap: () => onProduct(featured),
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(border: Border.all(color: Palette.border),
                  borderRadius: BorderRadius.circular(18)),
                child: Row(children: [
                  Container(height: 70, width: 64,
                    decoration: BoxDecoration(color: const Color(0x1AFFDE19),
                      borderRadius: BorderRadius.circular(15)),
                    child: const Icon(Icons.hub_outlined, color: Palette.primary, size: 32)),
                  const SizedBox(width: 15),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(ua ? 'МОДЕЛЬ  /  02' : 'MODEL  /  02',
                        style: const TextStyle(fontSize: 9, color: Palette.primary,
                          letterSpacing: 1.2, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 6),
                      const Text('LuckyStrike-2',
                        style: TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
                      const SizedBox(height: 5),
                      Text(ua ? 'Відкрити картку' : 'View product',
                        style: const TextStyle(color: Palette.secondary, fontSize: 11)),
                    ])),
                  const Icon(CupertinoIcons.chevron_right, size: 18,
                    color: Palette.primary),
                ])),
            )),
          const SizedBox(height: 15),
          _NewsEntry(onTap: onNews, ukrainian: ua),
        ]))),
      ],
    );
  }
}

class _DashboardTile extends StatelessWidget {
  const _DashboardTile({required this.onTap, required this.icon,
    required this.kicker, required this.title, required this.description,
    required this.height, this.featured = false});
  final VoidCallback onTap;
  final IconData icon;
  final String kicker, title, description;
  final double height;
  final bool featured;
  @override
  Widget build(BuildContext context) => Material(
    color: featured ? Palette.primary : Palette.surfaceRaised,
    borderRadius: BorderRadius.circular(19),
    clipBehavior: Clip.antiAlias,
    child: InkWell(onTap: onTap,
      child: SizedBox(height: height, child: Stack(children: [
        if (featured) Positioned(right: -24, bottom: -65,
          child: Container(width: 190, height: 190,
            decoration: BoxDecoration(shape: BoxShape.circle,
              border: Border.all(color: const Color(0x400A0B0D), width: 1.3)))),
        Padding(padding: const EdgeInsets.all(17),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Icon(icon, color: featured ? Palette.background : Palette.primary, size: 21),
              const Spacer(),
              Icon(CupertinoIcons.arrow_up_right,
                color: featured ? Palette.background : Palette.secondary, size: 16),
            ]),
            const Spacer(),
            Text(kicker, style: TextStyle(fontSize: 9,
              letterSpacing: 1.1, fontWeight: FontWeight.w800,
              color: featured ? const Color(0xC9000000) : Palette.secondary)),
            const SizedBox(height: 5),
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontWeight: FontWeight.w900,
                fontSize: featured ? 23 : 19,
                color: featured ? Palette.background : Palette.foreground)),
            const SizedBox(height: 4),
            Text(description, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 10.5,
                color: featured ? const Color(0xC9000000) : Palette.secondary)),
          ])),
      ])),
    ),
  );
}

class _NewsEntry extends StatelessWidget {
  const _NewsEntry({required this.onTap, required this.ukrainian});
  final VoidCallback onTap;
  final bool ukrainian;
  @override
  Widget build(BuildContext context) => Material(
    color: Palette.surface,
    borderRadius: BorderRadius.circular(16),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(16),
      child: Padding(padding: const EdgeInsets.all(17),
        child: Row(children: [
          const Icon(CupertinoIcons.bell_fill, color: Palette.primary, size: 23),
          const SizedBox(width: 13),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(ukrainian ? 'Новини та сповіщення' : 'News & notifications',
              style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            const SizedBox(height: 3),
            Text(ukrainian ? 'Оновлення в одному місці' : 'Updates in one place',
              style: const TextStyle(color: Palette.secondary, fontSize: 11)),
          ])),
          const Icon(CupertinoIcons.chevron_right, color: Palette.primary, size: 17),
        ])),
    ),
  );
}

class _Metric extends StatelessWidget {
  const _Metric(this.value, this.description);
  final String value;
  final String description;
  @override
  Widget build(BuildContext context) => Container(
        height: 90,
        padding: const EdgeInsets.fromLTRB(12, 14, 9, 12),
        decoration: BoxDecoration(
          color: Palette.surface,
          border: Border.all(color: Palette.border, width: .8),
          borderRadius: BorderRadius.circular(17),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(value, style: const TextStyle(
              color: Palette.foreground,
              fontSize: 25,
              fontWeight: FontWeight.w900,
              letterSpacing: -.5,
            )),
            Text(description, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: Palette.secondary, fontSize: 10.5)),
          ],
        ),
      );
}

class ProductCard extends StatelessWidget {
  const ProductCard({
    super.key,
    required this.product,
    required this.ukrainian,
    required this.onTap,
  });
  final ProductInfo product;
  final bool ukrainian;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) => Material(
        color: Palette.surface,
        borderRadius: BorderRadius.circular(21),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Expanded(child: Stack(fit: StackFit.expand, children: [
              BrandPhoto(asset: product.image, label: product.name),
              Positioned(right: 10, bottom: 11, child: _DemoMediaTag()),
              Positioned(top: 13, left: 14,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                  decoration: BoxDecoration(
                    color: const Color(0xC20A0B0D),
                    borderRadius: BorderRadius.circular(7),
                  ),
                  child: Text(product.position, style: const TextStyle(
                    fontSize: 11,
                    letterSpacing: 1.1,
                    fontWeight: FontWeight.w800,
                  )),
                ),
              ),
            ])),
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 13, 15),
              child: Row(children: [
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(product.name, style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      fontSize: 16,
                      letterSpacing: -.4,
                    )),
                    const SizedBox(height: 3),
                    Text(localized(ukrainian,
                        product.subtitleUa, product.subtitleEn),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 10.5, color: Palette.secondary,
                      ),
                    ),
                  ],
                )),
                const Icon(CupertinoIcons.arrow_up_right,
                    size: 18, color: Palette.primary),
              ]),
            ),
          ]),
        ),
      );
}

class _SupportBanner extends StatelessWidget {
  const _SupportBanner({required this.ukrainian});
  final bool ukrainian;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(21),
        decoration: BoxDecoration(
          border: Border.all(color: Palette.border),
          borderRadius: BorderRadius.circular(21),
          gradient: const LinearGradient(
            colors: [Palette.surfaceRaised, Palette.surface],
          ),
        ),
        child: Row(children: [
          Container(
            height: 51,
            width: 51,
            decoration: BoxDecoration(
              color: const Color(0x25FFDE19),
              borderRadius: BorderRadius.circular(15),
            ),
            alignment: Alignment.center,
            child: const Icon(Icons.build_rounded,
                color: Palette.primary, size: 24),
          ),
          const SizedBox(width: 17),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(localized(ukrainian, 'Сервіс та підтримка', 'Service & support'),
                  style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
              const SizedBox(height: 5),
              Text(localized(ukrainian,
                  'Гарантійне обслуговування, ремонт і навчання.',
                  'Warranty, maintenance, and training.'),
                style: const TextStyle(
                  color: Palette.secondary, fontSize: 12.5, height: 1.45,
                ),
              ),
            ],
          )),
        ]),
      );
}

class CatalogScreen extends StatelessWidget {
  const CatalogScreen({
    super.key,
    required this.ukrainian,
    required this.onProduct,
  });
  final bool ukrainian;
  final ValueChanged<ProductInfo> onProduct;

  @override
  Widget build(BuildContext context) => CustomScrollView(
        key: const PageStorageKey('catalogScroll'),
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(child: Padding(
            padding: const EdgeInsets.fromLTRB(21, 30, 21, 25),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Kicker(localized(ukrainian, 'КАТАЛОГ', 'CATALOG')),
              const SizedBox(height: 14),
              LabelTitle(localized(ukrainian, 'Продукція', 'Products'),
                  fontSize: 38),
              const SizedBox(height: 11),
              Text(localized(ukrainian,
                'Інженерні рішення PG Robotics. Оберіть модель, щоб переглянути її сторінку.',
                'Engineering by PG Robotics. Select a model to view its profile.'),
                style: const TextStyle(
                  fontSize: 13.4,
                  color: Palette.secondary,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 20),
              Container(height: 1, color: Palette.border),
            ]),
          )),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(21, 0, 21, 30),
            sliver: SliverLayoutBuilder(
              builder: (context, constraints) {
                final availableWidth = constraints.crossAxisExtent;
                final narrow = availableWidth < 350;
                return SliverGrid(
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 13,
                    crossAxisSpacing: 13,
                    mainAxisExtent: narrow ? 232 : 258,
                  ),
                  delegate: SliverChildBuilderDelegate(
                    (context, index) => ProductCard(
                      product: allProducts[index],
                      ukrainian: ukrainian,
                      onTap: () => onProduct(allProducts[index]),
                    ),
                    childCount: allProducts.length,
                  ),
                );
              },
            ),
          ),
          SliverToBoxAdapter(child: Padded(child: Padding(
            padding: const EdgeInsets.only(bottom: 32),
            child: Text(localized(ukrainian,
                'Інформаційний каталог • Без оформлення замовлень',
                'Informational catalog • No ordering'),
              textAlign: TextAlign.center,
              style: const TextStyle(color: Palette.tertiary, fontSize: 11)),
          ))),
        ],
      );
}

class ProductDetail extends StatelessWidget {
  const ProductDetail({super.key, required this.product, required this.ukrainian});
  final ProductInfo product;
  final bool ukrainian;

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Palette.background,
        body: SafeArea(
          child: Column(children: [
            Container(
              height: 60,
              padding: const EdgeInsets.symmetric(horizontal: 13),
              child: Row(children: [
                IconButton(
                  tooltip: localized(ukrainian, 'Назад', 'Back'),
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(CupertinoIcons.back,
                    color: Palette.primary, size: 25),
                ),
                const Expanded(child: Center(
                  child: Text('PG ROBOTICS', style: TextStyle(
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                    fontSize: 12,
                  )),
                )),
                const SizedBox(width: 48),
              ]),
            ),
            Expanded(child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 335,
                    child: Stack(fit: StackFit.expand, children: [
                      BrandPhoto(asset: product.image, label: product.name),
                      const DecoratedBox(decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.bottomCenter,
                          end: Alignment.topCenter,
                          colors: [Palette.background, Color(0x000A0B0D)],
                        ),
                      )),
                      Positioned(
                        top: 21, left: 21,
                        child: Kicker('PG / ${product.position}'),
                      ),
                    ]),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(23, 0, 23, 45),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(product.name.toUpperCase(), style: const TextStyle(
                          fontSize: 33, height: 1.1,
                          fontWeight: FontWeight.w900,
                          letterSpacing: -1.2,
                        )),
                        const SizedBox(height: 9),
                        Text(localized(ukrainian,
                            product.subtitleUa, product.subtitleEn),
                          style: const TextStyle(
                            color: Palette.primary,
                            fontWeight: FontWeight.w700,
                            fontSize: 13.5,
                          ),
                        ),
                        const SizedBox(height: 25),
                        const Divider(color: Palette.border),
                        const SizedBox(height: 18),
                        Kicker(localized(ukrainian, 'ОПИС', 'OVERVIEW')),
                        const SizedBox(height: 13),
                        Text(localized(ukrainian,
                            product.bodyUa, product.bodyEn),
                          style: const TextStyle(
                            height: 1.65,
                            color: Color(0xFFCFD0D0),
                            fontSize: 15,
                          ),
                        ),
                        const SizedBox(height: 25),
                        YellowAction(
                          title: localized(ukrainian, 'Зв’язатися з менеджером', 'Contact a manager'),
                          icon: Icons.chat_rounded,
                          onTap: () => ContactActions.whatsapp(context, ukrainian),
                        ),
                        const SizedBox(height: 13),
                        TextButton.icon(
                          onPressed: () => ContactActions.phone(
                              context, ContactActions.salesPhone, ukrainian),
                          icon: const Icon(CupertinoIcons.phone, size: 17),
                          label: Text(localized(ukrainian, 'Зателефонувати', 'Call us')),
                          style: TextButton.styleFrom(foregroundColor: Palette.primary),
                        ),
                        const SizedBox(height: 25),
                        Container(
                          padding: const EdgeInsets.all(18),
                          decoration: BoxDecoration(
                            color: Palette.surface,
                            borderRadius: BorderRadius.circular(17),
                            border: Border.all(color: Palette.border),
                          ),
                          child: Row(children: [
                            const Icon(CupertinoIcons.info,
                              color: Palette.primary, size: 22),
                            const SizedBox(width: 13),
                            Expanded(child: Text(localized(ukrainian,
                              'Офіційні матеріали виробника додаються в розділ ресурсів застосунку.',
                              'Official manufacturer media is added to the app assets.'),
                              style: const TextStyle(
                                color: Palette.secondary,
                                fontSize: 12.5,
                                height: 1.5,
                              ),
                            )),
                          ]),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )),
          ]),
        ),
      );
}

class CompanyScreen extends StatelessWidget {
  const CompanyScreen({super.key, required this.ukrainian,
    required this.onBrowse, required this.onContact});
  final bool ukrainian;
  final VoidCallback onBrowse, onContact;

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
    key: const PageStorageKey('companyScroll'),
    physics: const BouncingScrollPhysics(),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const SizedBox(height: 30),
      Padded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Kicker(localized(ukrainian, 'ПРО КОМПАНІЮ', 'ABOUT US')),
        const SizedBox(height: 14),
        LabelTitle(localized(ukrainian,
            'ІНЖЕНЕРІЯ.\nТЕХНОЛОГІЇ.\nДІЯ.',
            'ENGINEERING.\nTECHNOLOGY.\nACTION.'), fontSize: 36),
        const SizedBox(height: 17),
        Text(localized(ukrainian,
            'PG Robotics — українська компанія, яка розробляє та виробляє безпілотні системи для сучасних задач.',
            'PG Robotics is a Ukrainian company that develops and manufactures unmanned systems for modern needs.'),
          style: const TextStyle(
            color: Color(0xFFCFD0D0), fontSize: 14, height: 1.65,
          ),
        ),
      ])),
      const SizedBox(height: 28),
      const SizedBox(height: 255,
          child: BrandPhoto(asset: 'assets/images/about.jpg',
              label: 'PG ROBOTICS')),
      const SizedBox(height: 29),
      Padded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Kicker(localized(ukrainian, 'ПІДХІД', 'OUR APPROACH')),
        const SizedBox(height: 15),
        LabelTitle(localized(ukrainian,
            'Точність у кожній деталі',
            'Precision in every detail'), fontSize: 26),
        const SizedBox(height: 16),
        Text(localized(ukrainian,
          'Компанія поєднує інженерні розробки, виробництво, сервіс та навчання. Системи PG Robotics використовуються підрозділами Сил оборони України.',
          'The company combines engineering, manufacturing, service, and training. PG Robotics systems are used by Ukrainian defense units.'),
          style: const TextStyle(color: Palette.secondary, fontSize: 14, height: 1.65),
        ),
        const SizedBox(height: 28),
        _ValueCard(
          icon: CupertinoIcons.lightbulb_fill,
          onTap: onBrowse,
          title: localized(ukrainian, 'Інновації', 'Innovation'),
          description: localized(ukrainian,
              'Власна розробка та постійне вдосконалення.',
              'In-house engineering and continuous development.'),
        ),
        const SizedBox(height: 11),
        _ValueCard(
          icon: Icons.shield_rounded,
          onTap: onContact,
          title: localized(ukrainian, 'Надійність', 'Reliability'),
          description: localized(ukrainian,
              'Увага до якості, тестування та підтримки.',
              'Focus on quality, testing, and support.'),
        ),
        const SizedBox(height: 11),
        _ValueCard(
          icon: CupertinoIcons.person_2_fill,
          onTap: onContact,
          title: localized(ukrainian, 'Підтримка', 'Support'),
          description: localized(ukrainian,
              'Сервіс, консультації та навчальні програми.',
              'Maintenance, consultation, and training programs.'),
        ),
        const SizedBox(height: 40),
      ])),
    ]),
  );
}

class _ValueCard extends StatelessWidget {
  const _ValueCard({
    required this.icon,
    required this.title,
    required this.description,
    required this.onTap,
  });
  final IconData icon;
  final String title;
  final String description;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Material(
    color: Palette.surface,
    borderRadius: BorderRadius.circular(17),
    child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(17),
      child: Container(padding: const EdgeInsets.all(17),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(17),
      border: Border.all(color: Palette.border),
      color: Palette.surface,
    ),
    child: Row(children: [
      Container(
        height: 46, width: 46,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: const Color(0x19FFDE19),
          borderRadius: BorderRadius.circular(13),
        ),
        child: Icon(icon, color: Palette.primary, size: 23),
      ),
      const SizedBox(width: 14),
      Expanded(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(
            fontWeight: FontWeight.w800, fontSize: 15)),
          const SizedBox(height: 4),
          Text(description, style: const TextStyle(
            color: Palette.secondary, fontSize: 12, height: 1.4)),
        ],
      )),
      const SizedBox(width: 6),
      const Icon(CupertinoIcons.chevron_right, size: 16, color: Palette.primary),
    ])),
    ),
  );
}

class ContactsScreen extends StatelessWidget {
  const ContactsScreen({super.key, required this.ukrainian});
  final bool ukrainian;

  Future<void> _copy(BuildContext context, String text) async {
    await Clipboard.setData(ClipboardData(text: text));
    HapticFeedback.selectionClick();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: Palette.surfaceRaised,
      duration: const Duration(seconds: 2),
      content: Text(localized(ukrainian,
          'Скопійовано: $text', 'Copied: $text')),
    ));
  }

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
        key: const PageStorageKey('contactsScroll'),
        physics: const BouncingScrollPhysics(),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(21, 30, 21, 42),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Kicker(localized(ukrainian, 'НА ЗВ’ЯЗКУ', 'GET IN TOUCH')),
            const SizedBox(height: 14),
            LabelTitle(localized(ukrainian, 'Контакти', 'Contacts'),
                fontSize: 38),
            const SizedBox(height: 13),
            Text(localized(ukrainian,
                'Питання про продукцію, сервіс або співпрацю? Наша команда на зв’язку.',
                'Questions about products, service or partnerships? Our team is here to help.'),
              style: const TextStyle(
                color: Palette.secondary, fontSize: 14, height: 1.6),
            ),
            const SizedBox(height: 29),
            _ContactTile(
              icon: CupertinoIcons.phone_fill,
              title: 'WhatsApp', value: '+380 67 301 0141',
              onTap: () => ContactActions.whatsapp(context, ukrainian),
              onCopy: () => _copy(context, '+380673010141'),
            ),
            const SizedBox(height: 12),
            _ContactTile(
              icon: Icons.build_rounded,
              title: localized(ukrainian, 'Технічна підтримка', 'Technical support'),
              value: '+380 67 530 9877',
              onTap: () => ContactActions.phone(context, ContactActions.supportPhone, ukrainian),
              onCopy: () => _copy(context, '+380675309877'),
            ),
            const SizedBox(height: 12),
            _ContactTile(
              icon: CupertinoIcons.envelope_fill,
              title: localized(ukrainian, 'Відділ продажу', 'Sales'),
              value: 'sales@pg-robotics.com',
              onTap: () => ContactActions.email(context, ContactActions.salesEmail, ukrainian),
              onCopy: () => _copy(context, 'sales@pg-robotics.com'),
            ),
            const SizedBox(height: 12),
            _ContactTile(
              icon: Icons.chat_bubble_rounded,
              title: localized(ukrainian, 'Сервіс', 'Support'),
              value: 'support@pg-robotics.com',
              onTap: () => ContactActions.email(context, ContactActions.supportEmail, ukrainian),
              onCopy: () => _copy(context, 'support@pg-robotics.com'),
            ),
            const SizedBox(height: 33),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Palette.surface,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Palette.border),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Icon(CupertinoIcons.info,
                    color: Palette.primary, size: 25),
                const SizedBox(height: 14),
                Text(localized(ukrainian,
                    'Прямий зв’язок', 'Direct communication'),
                  style: const TextStyle(fontWeight: FontWeight.w800,
                      fontSize: 17),
                ),
                const SizedBox(height: 8),
                Text(localized(ukrainian,
                    'Натисніть на контакт, щоб відкрити WhatsApp, телефон або пошту. Іконка праворуч копіює дані.',
                    'Tap a contact to open WhatsApp, phone or email. Use the icon on the right to copy details.'),
                  style: const TextStyle(
                    color: Palette.secondary, fontSize: 12.5, height: 1.55,
                  ),
                ),
              ]),
            ),
          ]),
        ),
      );
}

class _ContactTile extends StatelessWidget {
  const _ContactTile({
    required this.icon,
    required this.title,
    required this.value,
    required this.onTap,
    required this.onCopy,
  });
  final IconData icon;
  final String title;
  final String value;
  final VoidCallback onTap;
  final VoidCallback onCopy;

  @override
  Widget build(BuildContext context) => Material(
        color: Palette.surface,
        borderRadius: BorderRadius.circular(17),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(17),
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(color: Palette.border),
              borderRadius: BorderRadius.circular(17),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 16),
            child: Row(children: [
              Container(
                height: 43, width: 43,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Palette.surfaceRaised,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, color: Palette.primary, size: 21),
              ),
              const SizedBox(width: 13),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(
                    color: Palette.secondary,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w600,
                  )),
                  const SizedBox(height: 5),
                  Text(value, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
                ],
              )),
              IconButton(
                tooltip: 'Copy',
                onPressed: onCopy,
                icon: const Icon(CupertinoIcons.doc_on_doc,
                  color: Palette.secondary, size: 19),
              ),
            ]),
          ),
        ),
      );
}
